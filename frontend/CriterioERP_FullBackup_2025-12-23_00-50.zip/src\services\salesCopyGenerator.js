/**
 * Motor de Generación de Contenidos Persuasivos (Sales Copy)
 * Transforma especificaciones técnicas en beneficios tangibles para el cliente.
 */

export const SalesCopyGenerator = {

    /**
     * Genera el HTML completo de la descripción del producto.
     * @param {object} ticket - El objeto ticket completo
     * @returns {string} HTML estructurado
     */
    generateHtml(ticket) {
        const specs = this._extractSpecs(ticket);
        const benefits = this._getBenefits(specs);

        return `
            <div class="cd-product-description" style="font-family: system-ui, -apple-system, sans-serif; color: #333; line-height: 1.6;">
                
                <h3 style="color: #2563eb; font-size: 1.5rem; margin-bottom: 1rem;">
                    🔥 ¿Por qué elegir este ${ticket.marca || 'equipo'}?
                </h3>
                
                <p class="cd-hero-text" style="font-size: 1.1rem; margin-bottom: 2rem; font-weight: 500;">
                    ${benefits.summary}
                </p>
                
                <div class="cd-specs-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; background: #f8fafc; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0;">
                    
                    <div class="cd-spec-item">
                        <strong style="display: block; color: #475569; margin-bottom: 0.25rem;">🧠 Cerebro (Procesador)</strong>
                        <span style="font-size: 1.1rem; font-weight: 700; color: #0f172a;">${specs.cpuLabel}</span>
                        <div style="margin-top: 0.5rem; font-size: 0.9rem; color: #64748b;">${benefits.cpu}</div>
                    </div>

                    <div class="cd-spec-item">
                        <strong style="display: block; color: #475569; margin-bottom: 0.25rem;">⚡ Velocidad (RAM)</strong>
                        <span style="font-size: 1.1rem; font-weight: 700; color: #0f172a;">${specs.ramLabel}</span>
                        <div style="margin-top: 0.5rem; font-size: 0.9rem; color: #64748b;">${benefits.ram}</div>
                    </div>

                    <div class="cd-spec-item">
                        <strong style="display: block; color: #475569; margin-bottom: 0.25rem;">🚀 Espacio (Almacenamiento)</strong>
                        <span style="font-size: 1.1rem; font-weight: 700; color: #0f172a;">${specs.diskLabel}</span>
                        <div style="margin-top: 0.5rem; font-size: 0.9rem; color: #64748b;">${benefits.disk}</div>
                    </div>

                </div>

                <p class="cd-footer-note" style="margin-top: 2rem; padding-top: 1rem; border-top: 1px dashed #cbd5e1; font-size: 0.9rem; color: #64748b; text-align: center;">
                    ✅ Equipo 100% Verificado por Expertos Criterio Digital. <br/>
                    🛡️ Garantía incluida. 🚚 Despacho a todo Chile.
                </p>
            </div>
        `;
    },

    _extractSpecs(ticket) {
        // CPU
        const cpuBrand = ticket.additionalInfo?.cpuBrand || '';
        const cpuGen = ticket.additionalInfo?.cpuGen || '';
        const cpuLabel = `${cpuBrand} ${cpuGen}`.trim() || 'No especificado';

        // RAM
        let ramGB = 0;
        let ramLabel = "N/A";
        if (ticket.ram) {
            if (ticket.ram.detalles && ticket.ram.detalles.length > 0) {
                // Try to extract total GB
                ticket.ram.detalles.forEach(d => {
                    const match = d.match(/(\d+)GB/i);
                    if (match) ramGB += parseInt(match[1]);
                });
                ramLabel = `${ticket.ram.slots}x (${ticket.ram.detalles.join(' + ')})`;
                if (ramGB > 0) ramLabel = `${ramGB}GB Total`; // Clean override
            }
        }

        // DISK
        let isSSD = false;
        let diskLabel = "N/A";
        if (ticket.disco && ticket.disco.detalles) {
            diskLabel = ticket.disco.detalles.join(' + ');
            isSSD = diskLabel.toLowerCase().includes('ssd') || diskLabel.toLowerCase().includes('nvme');
        }

        return { cpuBrand, cpuGen, cpuLabel, ramGB, ramLabel, isSSD, diskLabel };
    },

    _getBenefits(specs) {
        const benefits = {
            summary: "Un equipo confiable preparado para acompañarte en tus desafíos diarios.",
            cpu: "Rendimiento estable para tus tareas habituales.",
            ram: "Fluidez básica para navegación y documentos.",
            disk: "Espacio suficiente para tus archivos."
        };

        // CPU Logic
        const cpuLower = specs.cpuLabel.toLowerCase();
        if (cpuLower.includes('i7') || cpuLower.includes('ryzen 7') || cpuLower.includes('m1 pro') || cpuLower.includes('m2') || cpuLower.includes('m3')) {
            benefits.cpu = "Potencia Bruta. Ideal para edición de video, diseño, programación y multitarea pesada.";
            benefits.summary = "Diseñado para profesionales que no pueden perder tiempo. Este equipo ofrece un rendimiento superior para tareas exigentes.";
        } else if (cpuLower.includes('i5') || cpuLower.includes('ryzen 5')) {
            benefits.cpu = "El equilibrio perfecto. Potencia de sobra para oficina avanzada, muchas pestañas y edición ligera.";
            benefits.summary = "El compañero ideal para el trabajo y estudio avanzado. Rápido, capaz y eficiente.";
        } else if (cpuLower.includes('i3') || cpuLower.includes('ryzen 3')) {
            benefits.cpu = "Eficiencia inteligente. Optimizado para navegación rápida, streaming y ofimática sin pausas.";
            benefits.summary = "Perfecto para estudiantes y hogar. Todo lo que necesitas para conectarte y trabajar fluido.";
        }

        // RAM Logic
        if (specs.ramGB >= 16) {
            benefits.ram = "Multitarea Real. Olvídate de cerrar pestañas; trabaja con múltiples aplicaciones pesadas al mismo tiempo.";
        } else if (specs.ramGB >= 8) {
            benefits.ram = "Agilidad diaria. Abre tus programas favoritos y navega por internet con soltura.";
        } else if (specs.ramGB > 0 && specs.ramGB < 8) {
            benefits.ram = "Básico para tareas esenciales.";
        }

        // Disk Logic
        if (specs.isSSD) {
            benefits.disk = "Velocidad Instantánea. Sistema inicia en segundos y los programas abren al instante. ¡Adiós a las esperas!";
        } else {
            benefits.disk = "Gran capacidad de almacenamiento para todas tus fotos, documentos y archivos.";
        }

        return benefits;
    }
};
