import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import { ProcessingProvider } from './context/ProcessingContext';
import { GlobalSearchProvider } from './context/GlobalSearchContext';
import { FinancialProvider } from './context/FinancialContext';
import GlobalSearchModal from './components/common/GlobalSearchModal';

// Static Import for Critical Layouts and Core Pages (Instant Load)
import DashboardLayout from './layouts/DashboardLayout';
import Login from './pages/Login';
import SmartHome from './components/SmartHome';
import Unauthorized from './pages/Unauthorized'; // Static Import
import Dashboard from './pages/Dashboard';
import KanbanBoard from './components/KanbanBoard';
import IngresoTicket from './pages/IngresoTicket';
import Inventory from './pages/Inventory';

// Lazy Imports for Secondary/Admin Pages (Optimization)
const Users = lazy(() => import('./pages/Users'));
const ProjectStatus = lazy(() => import('./pages/ProjectStatus'));
const SalesDashboard = lazy(() => import('./pages/SalesDashboard'));
const Settings = lazy(() => import('./pages/Settings'));
const PointOfSale = lazy(() => import('./pages/PointOfSale'));
const TaskManager = lazy(() => import('./pages/TaskManager'));
const ClientStatus = lazy(() => import('./pages/ClientStatus'));
// const Unauthorized = lazy(() => import('./pages/Unauthorized')); // Moved to static
const Utilities = lazy(() => import('./pages/Utilities'));
const LabelPlayground = lazy(() => import('./pages/LabelPlayground'));

// Loading Fallback (For Lazy Routes only)
const PageLoader = () => (
  <div className="flex flex-col items-center justify-center min-h-[60vh] text-blue-500 animate-pulse">
    <div className="w-12 h-12 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin mb-4"></div>
    <span className="text-sm font-medium">Cargando módulo...</span>
  </div>
);

function App() {
  return (
    <Router>
      <AuthProvider>
        <FinancialProvider>
          <ProcessingProvider>
            <GlobalSearchProvider>
              <Toaster position="top-right" />
              <GlobalSearchModal />
              {/* Suspense handles the Lazy Admin routes */}
              <Suspense fallback={<PageLoader />}>
                <Routes>
                  <Route path="/login" element={<Login />} />
                  <Route path="/status" element={<ClientStatus />} />
                  <Route path="/playground" element={<LabelPlayground />} />
                  <Route path="/unauthorized" element={<Unauthorized />} />

                  <Route path="/" element={
                    <ProtectedRoute>
                      <DashboardLayout />
                    </ProtectedRoute>
                  }>
                    {/* CORE ROUTES - No Suspense needed (Static) */}
                    <Route index element={<SmartHome />} />

                    <Route path="tickets" element={
                      <ProtectedRoute module="tickets">
                        <KanbanBoard />
                      </ProtectedRoute>
                    } />

                    <Route path="inventory" element={
                      <ProtectedRoute module="inventory">
                        <Inventory />
                      </ProtectedRoute>
                    } />

                    <Route path="ingreso" element={
                      <ProtectedRoute module="ingreso">
                        <IngresoTicket />
                      </ProtectedRoute>
                    } />

                    <Route path="dashboard" element={
                      <ProtectedRoute module="dashboard">
                        <Dashboard />
                      </ProtectedRoute>
                    } />

                    {/* LAZY ADMIN ROUTES */}
                    <Route path="sales" element={
                      <ProtectedRoute module="sales" allowedRoles={['Admin']}>
                        <SalesDashboard />
                      </ProtectedRoute>
                    } />

                    <Route path="roadmap" element={
                      <ProtectedRoute module="roadmap">
                        <ProjectStatus />
                      </ProtectedRoute>
                    } />

                    <Route path="users" element={
                      <ProtectedRoute module="users" allowedRoles={['Admin']}>
                        <Users />
                      </ProtectedRoute>
                    } />

                    <Route path="pos" element={
                      <ProtectedRoute module="pos">
                        <PointOfSale />
                      </ProtectedRoute>
                    } />

                    <Route path="tasks" element={
                      <ProtectedRoute module="tasks">
                        <TaskManager />
                      </ProtectedRoute>
                    } />

                    <Route path="settings" element={
                      <ProtectedRoute module="settings" allowedRoles={['Admin']}>
                        <Settings />
                      </ProtectedRoute>
                    } />

                    <Route path="utilities" element={
                      <ProtectedRoute module="utilities" allowedRoles={['Admin']}>
                        <Utilities />
                      </ProtectedRoute>
                    } />

                  </Route>

                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </Suspense>
            </GlobalSearchProvider>
          </ProcessingProvider>
        </FinancialProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;
