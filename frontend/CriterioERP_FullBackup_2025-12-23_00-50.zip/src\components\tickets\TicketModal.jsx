import { useState, useEffect } from 'react';
import { X, Printer } from 'lucide-react';

export default function TicketModal({ isOpen, onClose, checkTicket, onSave }) {
    const [formData, setFormData] = useState({
        customerName: '',
        contactInfo: '',
        deviceType: '',
        deviceModel: '',
        description: '',
        priority: 'Normal',
        status: 'Pending',
        estimatedCost: 0
    });

    useEffect(() => {
        if (checkTicket) {
            setFormData(checkTicket);
        } else {
            setFormData({
                customerName: '',
                contactInfo: '',
                deviceType: '',
                deviceModel: '',
                description: '',
                priority: 'Normal',
                status: 'Pending',
                estimatedCost: 0
            });
        }
    }, [checkTicket, isOpen]);

    if (!isOpen) return null;

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave(formData);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: name === 'estimatedCost' ? parseFloat(value) : value
        }));
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
            <div className="w-full max-w-2xl rounded-xl bg-white shadow-2xl">
                <div className="flex items-center justify-between border-b p-6">
                    <h2 className="text-xl font-bold text-gray-900">
                        {checkTicket ? 'Edit Ticket' : 'New Repair Ticket'}
                    </h2>
                    <button onClick={onClose} className="rounded-lg p-2 hover:bg-gray-100">
                        <X className="h-6 w-6 text-gray-500" />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6">
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">

                        {/* Customer Info */}
                        <div className="md:col-span-2">
                            <h3 className="mb-3 text-sm font-semibold uppercase text-gray-500">Customer Details</h3>
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-gray-700">Customer Name</label>
                            <input
                                type="text"
                                name="customerName"
                                value={formData.customerName}
                                onChange={handleChange}
                                className="block w-full rounded-lg border border-gray-300 p-2.5 text-sm focus:border-blue-500 focus:ring-blue-500"
                                required
                            />
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-gray-700">Contact / Phone</label>
                            <input
                                type="text"
                                name="contactInfo"
                                value={formData.contactInfo}
                                onChange={handleChange}
                                className="block w-full rounded-lg border border-gray-300 p-2.5 text-sm focus:border-blue-500 focus:ring-blue-500"
                                required
                            />
                        </div>

                        {/* Device Info */}
                        <div className="md:col-span-2">
                            <h3 className="mb-3 mt-2 text-sm font-semibold uppercase text-gray-500">Device Information</h3>
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-gray-700">Device Type</label>
                            <select
                                name="deviceType"
                                value={formData.deviceType}
                                onChange={handleChange}
                                className="block w-full rounded-lg border border-gray-300 p-2.5 text-sm focus:border-blue-500 focus:ring-blue-500"
                                required
                            >
                                <option value="">Select Type</option>
                                <option value="Laptop">Laptop</option>
                                <option value="Desktop">Desktop</option>
                                <option value="Mobile">Mobile Phone</option>
                                <option value="Tablet">Tablet</option>
                                <option value="Printer">Printer</option>
                                <option value="Console">Game Console</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-gray-700">Model / Serial</label>
                            <input
                                type="text"
                                name="deviceModel"
                                value={formData.deviceModel}
                                onChange={handleChange}
                                className="block w-full rounded-lg border border-gray-300 p-2.5 text-sm focus:border-blue-500 focus:ring-blue-500"
                                placeholder="e.g. iPhone 13, Dell XPS..."
                            />
                        </div>

                        <div className="md:col-span-2">
                            <label className="mb-2 block text-sm font-medium text-gray-700">Problem Description</label>
                            <textarea
                                name="description"
                                value={formData.description}
                                onChange={handleChange}
                                rows="3"
                                className="block w-full rounded-lg border border-gray-300 p-2.5 text-sm focus:border-blue-500 focus:ring-blue-500"
                                required
                            ></textarea>
                        </div>

                        {/* Status & Priority */}
                        <div>
                            <label className="mb-2 block text-sm font-medium text-gray-700">Priority</label>
                            <select
                                name="priority"
                                value={formData.priority}
                                onChange={handleChange}
                                className="block w-full rounded-lg border border-gray-300 p-2.5 text-sm focus:border-blue-500 focus:ring-blue-500"
                            >
                                <option value="Low">Low</option>
                                <option value="Normal">Normal</option>
                                <option value="High">High</option>
                                <option value="Urgent">Urgent</option>
                            </select>
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-gray-700">Status</label>
                            <select
                                name="status"
                                value={formData.status}
                                onChange={handleChange}
                                className="block w-full rounded-lg border border-gray-300 p-2.5 text-sm focus:border-blue-500 focus:ring-blue-500"
                            >
                                <option value="Pending">Pending</option>
                                <option value="Diagnosing">Diagnosing</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Waiting for Parts">Waiting for Parts</option>
                                <option value="Ready">Ready for Pickup</option>
                                <option value="Delivered">Delivered</option>
                            </select>
                        </div>

                        <div>
                            <label className="mb-2 block text-sm font-medium text-gray-700">Est. Cost ($)</label>
                            <input
                                type="number"
                                name="estimatedCost"
                                value={formData.estimatedCost}
                                onChange={handleChange}
                                className="block w-full rounded-lg border border-gray-300 p-2.5 text-sm focus:border-blue-500 focus:ring-blue-500"
                                min="0"
                            />
                        </div>
                    </div>

                    <div className="mt-8 flex justify-end space-x-3 border-t pt-6">
                        <button
                            type="button"
                            onClick={onClose}
                            className="rounded-lg border border-gray-300 bg-white px-5 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="rounded-lg bg-blue-700 px-5 py-2.5 text-sm font-medium text-white hover:bg-blue-800"
                        >
                            {checkTicket ? 'Update Ticket' : 'Create Ticket'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
