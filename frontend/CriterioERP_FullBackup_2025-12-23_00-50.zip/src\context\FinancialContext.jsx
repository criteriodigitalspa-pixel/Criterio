
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { db } from '../services/firebase';
import { collection, onSnapshot, query } from 'firebase/firestore';

const FinancialContext = createContext();

const FALLBACK_TYPE = 'DDR4';

export function FinancialProvider({ children }) {
    const [ramPrices, setRamPrices] = useState([]);
    const [loading, setLoading] = useState(true);

    // Real-time listener for price changes (important so green/red numbers update if price changes)
    useEffect(() => {
        const q = query(collection(db, 'hardware_prices'));
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const data = snapshot.docs.map(d => d.data());
            // Data format: { category: 'RAM', type: 'DDR4', capacity: '8GB', price: 15000 }
            setRamPrices(data.filter(p => p.category === 'RAM'));
            setLoading(false);
        }, (error) => {
            console.error("Financials Context Error:", error);
            setLoading(false);
        });
        return () => unsubscribe();
    }, []);

    // Helper to find price
    const getRamPrice = useCallback((capacity, type = FALLBACK_TYPE) => {
        if (!capacity) return 0;
        const cap = capacity.toString().trim();

        // Exact match attempt
        const match = ramPrices.find(p => p.capacity === cap && p.type === type);
        if (match) return Number(match.price);

        // Fallback: Find ANY RAM with this capacity
        const partial = ramPrices.filter(p => p.capacity === cap);
        if (partial.length > 0) {
            const fb = partial.find(p => p.type === FALLBACK_TYPE);
            return Number(fb ? fb.price : partial[0].price);
        }

        return 0;
    }, [ramPrices]);

    /**
     * Calculates:
     * - Base Cost (Purchase)
     * - Hardware Additions/Removals value
     * - Total Ticket Cost
     */
    const calculateFinancials = useCallback((ticket) => {
        if (!ticket) return { baseCost: 0, ramDelta: 0, totalCost: 0, changes: [] };

        const baseCost = Number(ticket.precioCompra) || 0;

        // --- RAM DELTA ---
        // If ticket has "originalSpecs" we compare with "ticket.ram"
        // If not, delta is 0.

        let ramDelta = 0;
        let originalRamVal = 0;
        let currentRamVal = 0;

        if (ticket.originalSpecs?.ram?.detalles) {
            const origDetails = ticket.originalSpecs.ram.detalles;
            const currDetails = ticket.ram?.detalles || [];

            origDetails.forEach(cap => originalRamVal += getRamPrice(cap));
            currDetails.forEach(cap => currentRamVal += getRamPrice(cap));

            ramDelta = currentRamVal - originalRamVal;
        }

        // --- DISK DELTA (Placeholder for future) ---
        let diskDelta = 0;

        // Total
        const totalCost = baseCost + ramDelta + diskDelta;

        return {
            baseCost,
            ramDelta,
            originalRamVal,
            currentRamVal,
            totalCost,
            isModified: ramDelta !== 0
        };
    }, [getRamPrice]);

    return (
        <FinancialContext.Provider value={{ ramPrices, loading, getRamPrice, calculateFinancials }}>
            {children}
        </FinancialContext.Provider>
    );
}

export const useFinancialsContext = () => useContext(FinancialContext);
