import { db } from './firebase';
import { SalesCopyGenerator } from './salesCopyGenerator';
// If using a library like 'woocommerce-rest-api' is preferred, we can add it later.
// For now, raw fetch is efficient.

const WC_URL = import.meta.env.VITE_WC_URL;
const WC_KEY = import.meta.env.VITE_WC_KEY;
const WC_SECRET = import.meta.env.VITE_WC_SECRET;

class WooCommerceService {
    constructor() {
        if (!WC_URL || !WC_KEY || !WC_SECRET) {
            console.warn("WooCommerce credentials missing in environment variables.");
        }
        this.baseUrl = `${WC_URL}/wp-json/wc/v3`;
    }

    /**
     * Helper for Basic Auth and Headers
     */
    _getHeaders() {
        const auth = btoa(`${WC_KEY}:${WC_SECRET}`);
        return {
            'Authorization': `Basic ${auth}`,
            'Content-Type': 'application/json'
        };
    }

    /**
     * Check if a product exists by SKU (Ticket ID).
     * @param {string} sku - The Ticket ID (e.g., "25-0001")
     * @returns {Promise<object|null>} The WooCommerce product object if found, null otherwise.
     */
    async getProductBySku(sku) {
        try {
            const response = await fetch(`${this.baseUrl}/products?sku=${sku}`, {
                method: 'GET',
                headers: this._getHeaders()
            });

            if (!response.ok) throw new Error(`WC Error: ${response.statusText}`);

            const data = await response.json();
            return data.length > 0 ? data[0] : null;
        } catch (error) {
            console.error("Error searching product in WC:", error);
            return null;
        }
    }

    /**
     * Create a new product in WooCommerce.
     * @param {object} productData - Payload for WC API
     */
    async createProduct(productData) {
        try {
            const response = await fetch(`${this.baseUrl}/products`, {
                method: 'POST',
                headers: this._getHeaders(),
                body: JSON.stringify(productData)
            });

            if (!response.ok) {
                const errorBody = await response.text();
                throw new Error(`Failed to create product: ${errorBody}`);
            }

            return await response.json();
        } catch (error) {
            console.error("Error creating product in WC:", error);
            throw error;
        }
    }

    /**
     * Update an existing product in WooCommerce.
     * @param {number} id - WooCommerce Product ID
     * @param {object} updates - Fields to update
     */
    async updateProduct(id, updates) {
        try {
            const response = await fetch(`${this.baseUrl}/products/${id}`, {
                method: 'PUT',
                headers: this._getHeaders(),
                body: JSON.stringify(updates)
            });

            if (!response.ok) {
                const errorBody = await response.text();
                throw new Error(`Failed to update product: ${errorBody}`);
            }

            return await response.json();
        } catch (error) {
            console.error("Error updating product in WC:", error);
            throw error;
        }
    }

    /**
     * Main Sync Method (Idempotent)
     * @param {object} ticket - The full ticket object from Firestore
     * @param {number|string} salePrice - The defined selling price
     */
    async syncProduct(ticket, salePrice) {
        if (!ticket || !ticket.ticketId) {
            throw new Error("Invalid ticket data for sync.");
        }

        if (!salePrice) {
            console.warn("Syncing without sale price (will be 0 or draft?) - Ideally required.");
        }

        const sku = ticket.ticketId;
        const productData = this.mapTicketToProduct(ticket, salePrice);

        // 1. Check Existence
        const existingProduct = await this.getProductBySku(sku);

        if (existingProduct) {
            // 2a. Update
            console.log(`[WC Sync] Product ${sku} exists (ID: ${existingProduct.id}). Updating...`);

            // We update everything to ensure consistency, or just price/stock as requested?
            // "Si existe, solo actualiza precio y stock" - per user request.
            const updates = {
                regular_price: String(salePrice),
                stock_quantity: 1,
                manage_stock: true,
                status: 'publish' // Ensure it's live
            };
            return await this.updateProduct(existingProduct.id, updates);

        } else {
            // 2b. Create
            console.log(`[WC Sync] Creating new product for ${sku}...`);
            return await this.createProduct(productData);
        }
    }

    /**
     * Map Firestore Ticket to WooCommerce Product Payload
     */
    mapTicketToProduct(ticket, salePrice) {
        // Construct Title
        const title = `${ticket.marca || 'Generico'} ${ticket.modelo || 'Modelo'} ${ticket.additionalInfo?.cpuBrand || ''}`.trim();

        // Construct HTML Description
        // Using provided fields: Processor, RAM, Storage
        const cpu = `${ticket.additionalInfo?.cpuBrand || ''} ${ticket.additionalInfo?.cpuGen || ''}`.trim();

        let ram = "N/A";
        if (ticket.ram) {
            if (ticket.ram.detalles && ticket.ram.detalles.length > 0) {
                ram = `${ticket.ram.slots}x (${ticket.ram.detalles.join(' + ')})`;
            } else if (ticket.ram.slots === 0) {
                ram = "Sin RAM";
            }
        }

        let disco = "N/A";
        if (ticket.disco) {
            if (ticket.disco.detalles && ticket.disco.detalles.length > 0) {
                disco = ticket.disco.detalles.join(' + ');
            } else if (ticket.disco.slots === 0) {
                disco = "Sin Almacenamiento";
            }
        }

        // Use AI Sales Copy Generator
        let descriptionHtml = '';
        try {
            descriptionHtml = SalesCopyGenerator.generateHtml(ticket);
        } catch (e) {
            console.error("Error generating sales copy:", e);
            descriptionHtml = `<ul><li>Error generando descripción: ${e.message}</li></ul>`;
        }

        return {
            name: title,
            type: 'simple',
            regular_price: String(salePrice || '0'),
            description: descriptionHtml,
            short_description: ticket.modeloAlias || '',
            sku: ticket.ticketId,
            manage_stock: true,
            stock_quantity: 1,
            categories: [
                { id: 16 } // Fixed Category ID
            ],
            status: 'publish'
        };
    }
}

export const wooCommerceService = new WooCommerceService();
