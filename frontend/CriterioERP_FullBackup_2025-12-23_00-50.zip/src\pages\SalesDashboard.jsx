import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { useRole } from '../hooks/useRole';
import { ticketService } from '../services/ticketService';
import { DollarSign, TrendingUp, Calendar, Search, FileText, ChevronDown, Filter, PieChart, Wallet, CreditCard, Activity } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import toast from 'react-hot-toast';

export default function SalesDashboard() {
    const { user } = useAuth();
    const { role, loading: roleLoading } = useRole();
    const navigate = useNavigate();

    const [tickets, setTickets] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filterMonth, setFilterMonth] = useState(new Date().toISOString().slice(0, 7)); // YYYY-MM
    const [searchTerm, setSearchTerm] = useState('');

    // --- SECURITY CHECK (Admin Only) ---
    useEffect(() => {
        if (!roleLoading) {
            if (role !== 'Admin') {
                toast.error("Acceso restringido: Solo Administradores");
                navigate('/unauthorized');
            }
        }
    }, [role, roleLoading, navigate]);

    // --- DATA FETCHING ---
    useEffect(() => {
        const fetchSales = async () => {
            setLoading(true);
            try {
                // Fetch all tickets. Ideally, we should have a backend query for 'Ventas' or 'status=closed'
                // For now, we filter client-side to keep it simple with existing service
                const allTickets = await ticketService.getAllTickets();

                // Filter for "Sold" tickets. 
                // Logic: currentArea == 'Ventas' OR (status == 'closed' AND has price)
                // Since we just removed 'Ventas' column from UI but kept Logic, we rely on the Area name stored in DB.
                // Or looking for tickets that went through the 'Sold' process.
                // Let's assume tickets in 'Ventas' area if we moved them there, OR checks for existence of 'precioVenta'.
                const soldTickets = allTickets.filter(t =>
                    t.currentArea === 'Ventas' ||
                    (t.precioVenta && t.precioVenta > 0)
                );

                setTickets(soldTickets);
            } catch (error) {
                console.error("Error fetching sales:", error);
                toast.error("Error al cargar ventas");
            } finally {
                setLoading(false);
            }
        };

        if (role === 'Admin') {
            fetchSales();
        }
    }, [role]);

    // --- CALCULATIONS & FILTERING ---
    const filteredData = useMemo(() => {
        return tickets.filter(t => {
            // Date Filter (using 'fechaSalida' or 'updatedAt' as sale date approximation)
            // Use ticket.fechaSalida if exists, else ticket.updatedAt
            const saleDate = t.fechaSalida || (t.updatedAt?.seconds ? new Date(t.updatedAt.seconds * 1000).toISOString() : '') || '';
            const ticketMonth = saleDate.slice(0, 7);
            const matchesDate = !filterMonth || ticketMonth === filterMonth;

            // Search Filter
            const lowerTerm = searchTerm.toLowerCase();
            const matchesSearch = !searchTerm ||
                t.ticketId?.toLowerCase().includes(lowerTerm) ||
                t.nombreCliente?.toLowerCase().includes(lowerTerm) ||
                t.modelo?.toLowerCase().includes(lowerTerm);

            return matchesDate && matchesSearch;
        });
    }, [tickets, filterMonth, searchTerm]);

    const stats = useMemo(() => {
        let totalBruto = 0;
        let totalCostos = 0;

        filteredData.forEach(t => {
            const precio = parseFloat(t.precioVenta) || 0;
            const costos = parseFloat(t.costosExtra) || 0; // Buying price? 
            // Usually 'precioCompra' is buying price, 'costosExtra' are repairs.
            const compra = parseFloat(t.precioCompra) || 0;

            totalBruto += precio;
            totalCostos += (compra + costos);
        });

        const iva = Math.round(totalBruto * 0.19); // 19% Tax approx (or included)
        // If price includes Tax: Net = Gross / 1.19
        // Let's assume Price is Gross for now.
        const neto = Math.round(totalBruto / 1.19);
        const ivaReal = totalBruto - neto;
        const ganancia = neto - totalCostos;

        return {
            count: filteredData.length,
            gross: totalBruto,
            net: neto,
            tax: ivaReal,
            costs: totalCostos,
            profit: ganancia,
            margin: totalBruto > 0 ? ((ganancia / totalBruto) * 100).toFixed(1) : 0
        };
    }, [filteredData]);

    const formatMoney = (amount) => {
        return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(amount);
    };

    if (roleLoading || loading) return (
        <div className="min-h-screen bg-[#0f172a] flex items-center justify-center">
            <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
        </div>
    );

    return (
        <div className="min-h-screen bg-[#0f172a] text-gray-100 p-8 pb-32">

            {/* HEADER */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-6">
                <div>
                    <h1 className="text-4xl font-black tracking-tight text-white flex items-center gap-3">
                        <TrendingUp className="text-green-400 w-10 h-10" />
                        DASHBOARD COMERCIAL
                    </h1>
                    <p className="text-gray-400 mt-2 text-lg">Resumen financiero y gestión de ventas.</p>
                </div>

                <div className="flex flex-wrap gap-4 items-center bg-gray-900/50 p-2 rounded-2xl border border-gray-700/50 backdrop-blur-md">
                    <div className="relative group">
                        <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-blue-400 w-5 h-5" />
                        <input
                            type="month"
                            value={filterMonth}
                            onChange={(e) => setFilterMonth(e.target.value)}
                            className="bg-gray-800 border border-gray-700 rounded-xl py-2 pl-10 pr-4 text-white focus:ring-2 focus:ring-blue-500 outline-none"
                        />
                    </div>
                    <div className="relative group w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-blue-400 w-5 h-5" />
                        <input
                            type="text"
                            placeholder="Buscar venta..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full bg-gray-800 border border-gray-700 rounded-xl py-2 pl-10 pr-4 text-white focus:ring-2 focus:ring-blue-500 outline-none"
                        />
                    </div>
                </div>
            </div>

            {/* KPI CARDS */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                {/* VENTAS TOTALES */}
                <div className="relative overflow-hidden bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-3xl border border-gray-700/50 shadow-2xl group hover:border-blue-500/30 transition-all">
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
                        <Wallet className="w-24 h-24 text-blue-400" />
                    </div>
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-2 text-blue-400 font-bold uppercase tracking-wider text-xs">
                            <Activity className="w-4 h-4" /> Ventas Totales
                        </div>
                        <div className="text-3xl font-black text-white">{formatMoney(stats.gross)}</div>
                        <div className="text-sm text-gray-400 mt-1">{stats.count} Transacciones</div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 to-transparent opacity-50"></div>
                </div>

                {/* GANANCIA */}
                <div className="relative overflow-hidden bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-3xl border border-gray-700/50 shadow-2xl group hover:border-green-500/30 transition-all">
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
                        <PieChart className="w-24 h-24 text-green-400" />
                    </div>
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-2 text-green-400 font-bold uppercase tracking-wider text-xs">
                            <TrendingUp className="w-4 h-4" /> Utilidad Neta
                        </div>
                        <div className="text-3xl font-black text-white">{formatMoney(stats.profit)}</div>
                        <div className="text-sm text-green-400/80 mt-1 font-bold">Margen: {stats.margin}%</div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-green-500 to-transparent opacity-50"></div>
                </div>

                {/* IVA */}
                <div className="relative overflow-hidden bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-3xl border border-gray-700/50 shadow-2xl group hover:border-amber-500/30 transition-all">
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
                        <FileText className="w-24 h-24 text-amber-400" />
                    </div>
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-2 text-amber-400 font-bold uppercase tracking-wider text-xs">
                            <DollarSign className="w-4 h-4" /> IVA (19%)
                        </div>
                        <div className="text-3xl font-black text-white">{formatMoney(stats.tax)}</div>
                        <div className="text-sm text-gray-400 mt-1">Impuesto a pagar</div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 to-transparent opacity-50"></div>
                </div>

                {/* COSTOS */}
                <div className="relative overflow-hidden bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-3xl border border-gray-700/50 shadow-2xl group hover:border-red-500/30 transition-all">
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
                        <CreditCard className="w-24 h-24 text-red-400" />
                    </div>
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-2 text-red-400 font-bold uppercase tracking-wider text-xs">
                            <DollarSign className="w-4 h-4" /> Costos Totales
                        </div>
                        <div className="text-3xl font-black text-white">{formatMoney(stats.costs)}</div>
                        <div className="text-sm text-gray-400 mt-1">Compras + Reparaciones</div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 to-transparent opacity-50"></div>
                </div>
            </div>

            {/* TABLE */}
            <div className="bg-gray-900/40 rounded-3xl border border-gray-700/50 overflow-hidden backdrop-blur-sm shadow-2xl">
                <div className="p-6 border-b border-gray-700/50 flex justify-between items-center">
                    <h2 className="text-lg font-bold text-white flex items-center gap-2">
                        <FileText className="w-5 h-5 text-gray-400" /> Transacciones Recientes
                    </h2>
                    <span className="text-xs bg-gray-800 px-3 py-1 rounded-full text-gray-400">{filteredData.length} registros</span>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="border-b border-gray-700/50 text-xs uppercase tracking-wider text-gray-500">
                                <th className="p-4 font-bold">Fecha</th>
                                <th className="p-4 font-bold">ID / Cliente</th>
                                <th className="p-4 font-bold">Equipo</th>
                                <th className="p-4 font-bold text-right text-red-400/80">Costo Total</th>
                                <th className="p-4 font-bold text-right text-blue-400/80">P. Venta</th>
                                <th className="p-4 font-bold text-right text-green-400/80">Utilidad</th>
                                <th className="p-4 font-bold text-center">Ticket</th>
                            </tr>
                        </thead>
                        <tbody className="text-sm divide-y divide-gray-800/50">
                            {filteredData.length === 0 ? (
                                <tr>
                                    <td colSpan="7" className="p-12 text-center text-gray-500 italic">
                                        <div className="flex flex-col items-center gap-2">
                                            <Search className="w-8 h-8 opacity-50" />
                                            <span>No se encontraron ventas en este periodo.</span>
                                        </div>
                                    </td>
                                </tr>
                            ) : (
                                filteredData.map(ticket => {
                                    // Row Calcs
                                    const venta = parseFloat(ticket.precioVenta) || 0;
                                    const costo = (parseFloat(ticket.precioCompra) || 0) + (parseFloat(ticket.costosExtra) || 0);
                                    const neto = venta / 1.19;
                                    const utilidad = neto - costo;

                                    return (
                                        <tr key={ticket.id} className="hover:bg-gray-800/30 transition-colors group">
                                            <td className="p-4 font-mono text-gray-400 whitespace-nowrap">
                                                {ticket.fechaSalida || (ticket.updatedAt?.seconds ? new Date(ticket.updatedAt.seconds * 1000).toLocaleDateString() : '-')}
                                            </td>
                                            <td className="p-4">
                                                <div className="font-bold text-white group-hover:text-blue-400 transition-colors">{ticket.ticketId}</div>
                                                <div className="text-xs text-gray-500">{ticket.nombreCliente}</div>
                                            </td>
                                            <td className="p-4 text-gray-300">
                                                <div className="font-medium">{ticket.marca} {ticket.modelo}</div>
                                                <div className="text-xs text-gray-500">
                                                    {ticket.ram?.detalles?.join(', ') || ticket.ram || '-'} • {ticket.disco?.detalles?.join(', ') || ticket.disco || '-'}
                                                </div>
                                            </td>
                                            <td className="p-4 text-right font-mono text-gray-400">
                                                {formatMoney(costo)}
                                            </td>
                                            <td className="p-4 text-right font-mono font-bold text-white">
                                                {formatMoney(venta)}
                                            </td>
                                            <td className={clsx("p-4 text-right font-mono font-bold", utilidad > 0 ? "text-green-400" : "text-red-400")}>
                                                {formatMoney(utilidad)}
                                            </td>
                                            <td className="p-4 text-center">
                                                <button className="text-gray-500 hover:text-white transition-colors" title="Ver Detalle Ticket">
                                                    <ChevronDown className="w-5 h-5 mx-auto" />
                                                </button>
                                            </td>
                                        </tr>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
