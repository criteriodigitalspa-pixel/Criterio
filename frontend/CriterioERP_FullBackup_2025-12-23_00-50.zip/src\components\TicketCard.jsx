import React from 'react';
import clsx from 'clsx';
import {
    Hash, Eye, Cpu, Layers, HardDrive, CheckSquare, FileText, ArrowRight, Clock, CheckCircle, Flame, Wrench, MessageCircle, Truck
} from 'lucide-react';
import { getSLAStatus } from '../services/slaService';
import CostDisplay from './common/CostDisplay';
import { useAuth } from '../context/AuthContext';

const TicketCard = React.memo(({
    ticket,
    selectionMode,
    isSelected,
    onToggleSelection,
    onDragStart,
    onDetail,
    onQA,
    onInfo,
    onDispatch,
    onSLA,
    onMove
}) => {
    // Permission check
    const { userProfile } = useAuth();
    const canViewFinancials = userProfile?.roles?.includes('admin') || userProfile?.role === 'Admin' || userProfile?.permissions?.financials?.view;

    // Helper for date formatting
    const formatDate = (date) => {
        if (!date) return '-';
        if (date?.seconds) return new Date(date.seconds * 1000).toLocaleDateString();
        return new Date(date).toLocaleDateString();
    };

    // Calculations for Info Progress
    const INFO_FIELDS = ['screenSize', 'screenRes', 'cpuBrand', 'cpuGen', 'gpuBrand', 'gpuModel', 'batteryHealth', 'serialNumber'];
    const infoFilledCount = ticket.additionalInfo ? INFO_FIELDS.filter(f => ticket.additionalInfo[f] && ticket.additionalInfo[f].trim() !== '').length : 0;
    const infoProgress = Math.round((infoFilledCount / INFO_FIELDS.length) * 100);
    const infoComplete = infoProgress === 100;

    // SLA Calculations
    const { status: slaStatus, elapsed, remaining } = getSLAStatus(ticket);
    const isSlaApplicable = slaStatus !== 'na';
    const isUrgent = isSlaApplicable && remaining < (4 * 60 * 60 * 1000); // 4 Hours warning

    const [showReason, setShowReason] = React.useState(false);

    // Helpers
    const isService = ['Servicio Rapido', 'Servicio Dedicado', 'Caja Espera', 'Diagnostico', 'Reparacion'].includes(ticket.currentArea || ticket.status);
    const isDespacho = ticket.currentArea && ticket.currentArea.includes("Despacho");

    // Auto-hide tooltip after 15s
    React.useEffect(() => {
        let timer;
        if (showReason) {
            timer = setTimeout(() => setShowReason(false), 15000);
        }
        return () => clearTimeout(timer);
    }, [showReason]);

    // Internal handler to maintain stability
    const handleDragStart = React.useCallback((e) => {
        if (onDragStart) onDragStart(e, ticket);
    }, [onDragStart, ticket]);

    return (
        <div
            draggable={!selectionMode}
            onDragStart={handleDragStart}
            onClick={() => {
                if (selectionMode && onToggleSelection) {
                    onToggleSelection(ticket.id);
                }
            }}
            className={clsx(
                "relative rounded-lg shadow-lg border transition-all duration-300 group",
                selectionMode
                    ? (isSelected ? "bg-blue-900/40 border-blue-500 ring-2 ring-blue-500 cursor-pointer" : "bg-gray-700/40 border-gray-600/30 opacity-70 hover:opacity-100 cursor-pointer")
                    : "bg-gray-700/40 border-gray-600/30 cursor-grab active:cursor-grabbing hover:bg-gray-700 hover:border-gray-500/50"
            )}
        >
            {/* SELECTION OVERLAY INDICATOR */}
            {selectionMode && (
                <div className="absolute top-2 right-2 z-20">
                    {isSelected
                        ? <CheckCircle className="w-6 h-6 text-blue-400 bg-gray-900 rounded-full" />
                        : <div className="w-6 h-6 rounded-full border-2 border-gray-500 bg-gray-800/50" />
                    }
                </div>
            )}

            {/* Header Row: ID, Batch ID - CLEANED UP */}
            <div className="flex items-start p-2.5 pb-1 relative pr-8">
                {/* URGENT INDICATOR */}
                {isUrgent && (
                    <div className="absolute -top-3 -left-2 z-30 animate-bounce text-orange-500 bg-gray-900 rounded-full p-1 border border-orange-500/50 shadow-[0_0_10px_rgba(249,115,22,0.6)]" title="¡Urgente! SLA Crítico">
                        <Flame className="w-4 h-4 fill-orange-600" />
                    </div>
                )}

                <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 bg-blue-900/30 text-blue-300 px-2 py-0.5 rounded border border-blue-500/20 shadow-sm w-fit">
                        <Hash className="w-3.5 h-3.5" /> <span className="text-sm font-mono font-black tracking-tight">{ticket.ticketId}</span>
                    </div>

                    {ticket.batchId && (
                        <div className="flex items-center gap-1 bg-purple-900/30 text-purple-300 px-1.5 py-0.5 rounded border border-purple-500/20 shadow-sm w-fit" title="ID de Lote">
                            <Layers className="w-2.5 h-2.5" /> <span className="text-[9px] font-mono font-bold">{ticket.batchId}</span>
                        </div>
                    )}
                </div>

                {/* Date relative to Header */}
                <span className="absolute top-2.5 right-10 text-[9px] text-gray-500" title={`Ingresado: ${formatDate(ticket.createdAt)}`}>
                    {formatDate(ticket.createdAt)}
                </span>
            </div>

            {/* RIGHT ACTION STACK (Absolute) */}
            <div className="absolute top-2 right-2 flex flex-col items-center gap-2 z-20">
                {/* 1. View Detail (Top) */}
                <button
                    onClick={(e) => { e.stopPropagation(); onDetail && onDetail(ticket); }}
                    className="p-1 text-gray-400 hover:text-white rounded transition-colors hover:bg-gray-600"
                    title="Ver Ficha Completa"
                >
                    <Eye className="w-4 h-4" />
                </button>

                {/* 2. Cost Display (Middle) */}
                {canViewFinancials && (
                    <CostDisplay ticket={ticket} compact="icon" />
                )}

                {/* 3. Service Icon (Bottom) */}
                {isService && (
                    <div className="relative">
                        <button
                            onClick={(e) => { e.stopPropagation(); setShowReason(!showReason); }}
                            className="p-1 text-yellow-500 hover:text-yellow-400 rounded transition-colors hover:bg-yellow-900/20"
                            title="Ver motivo de servicio"
                        >
                            <Wrench className="w-3.5 h-3.5" />
                        </button>
                        {/* REASON CLOUD (TOOLTIP) - Adjusted Position */}
                        {showReason && (
                            <div className="absolute top-0 right-8 w-64 bg-slate-800 text-gray-100 p-3 rounded-xl shadow-xl border border-slate-600 z-50 animate-in fade-in zoom-in-95 origin-top-right text-xs">
                                <div className="absolute top-2 -right-1.5 w-3 h-3 bg-slate-800 rotate-45 border-r border-t border-slate-600"></div>

                                {ticket.serviceActions && ticket.serviceActions.length > 0 ? (
                                    <>
                                        <div className="font-bold mb-2 flex items-center gap-2 border-b border-slate-700 pb-2 text-blue-400">
                                            <Wrench className="w-3.5 h-3.5" />
                                            <span>PRESUPUESTO ACTIVO</span>
                                        </div>
                                        <ul className="space-y-1.5 mb-2 max-h-40 overflow-y-auto custom-scrollbar px-1">
                                            {ticket.serviceActions.map((action, idx) => (
                                                <li key={idx} className="flex justify-between items-start gap-2 text-gray-300">
                                                    <span className="leading-tight text-[11px]">• {action.text}</span>
                                                    <span className="font-mono font-bold text-green-400">${(action.cost || 0).toLocaleString()}</span>
                                                </li>
                                            ))}
                                        </ul>
                                        <div className="flex justify-between items-center pt-2 border-t border-slate-700 font-bold">
                                            <span className="text-gray-400">TOTAL:</span>
                                            <span className="text-sm text-green-400 font-mono">${(ticket.totalServiceCost || 0).toLocaleString()}</span>
                                        </div>
                                    </>
                                ) : (
                                    <>
                                        <div className="font-bold mb-1 flex items-center gap-2 text-blue-400">
                                            <MessageCircle className="w-3.5 h-3.5" />
                                            <span>MOTIVO DE SERVICIO</span>
                                        </div>
                                        <p className="leading-relaxed text-gray-300">
                                            {ticket.motivo || ticket.problemDescription || ticket.observaciones || "Sin motivo especificado."}
                                        </p>
                                    </>
                                )}
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* Main Content Area */}
            <div className="px-3 pb-2 relative z-10 pr-8">
                {/* TAGS */}
                {ticket.tags && ticket.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-2">
                        {ticket.tags.map(tag => (
                            <span key={tag.id || tag.text} className={clsx("px-1.5 py-0.5 rounded text-[9px] font-bold shadow-sm uppercase tracking-wider", tag.color, tag.textColor || 'text-white')}>
                                {tag.text}
                            </span>
                        ))}
                    </div>
                )}

                <h4 className="font-bold text-gray-100 text-xs md:text-sm leading-tight mb-2 truncate uppercase" title={`${ticket.marca} ${ticket.modelo}`}>
                    {ticket.marca} {ticket.modelo}
                </h4>

                {/* Tech Specs Compact Grid - INCREASED TEXT SIZE */}
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 bg-gray-800/30 p-1.5 rounded-md border border-gray-700/30 mb-2">
                    <div className="flex items-center gap-1.5 overflow-hidden" title="Procesador">
                        <Cpu className="w-3 h-3 text-gray-500 shrink-0" />
                        <span className="truncate text-[10px] text-gray-300 font-medium">
                            {ticket.additionalInfo?.cpuBrand ? `${ticket.additionalInfo.cpuBrand} ${ticket.additionalInfo.cpuGen || ''}` : '-'}
                        </span>
                    </div>
                    <div className="flex items-center gap-1.5 overflow-hidden" title="Memoria RAM">
                        <Layers className="w-3 h-3 text-gray-500 shrink-0" />
                        <span className="truncate text-[10px] text-gray-300 font-medium">
                            {ticket.ram?.detalles?.join('+') || '-'}
                        </span>
                    </div>
                    <div className="flex items-center gap-1.5 overflow-hidden" title="Almacenamiento">
                        <HardDrive className="w-3 h-3 text-gray-500 shrink-0" />
                        <span className="truncate text-[10px] text-gray-300 font-medium">
                            {ticket.disco?.detalles?.join('+') || '-'}
                        </span>
                    </div>
                    <div className="flex items-center gap-1.5 overflow-hidden" title="S/N">
                        <Hash className="w-3 h-3 text-gray-500 shrink-0" />
                        <span className="truncate text-[10px] text-gray-400 font-mono">
                            {ticket.additionalInfo?.serialNumber || '-'}
                        </span>
                    </div>
                </div>

                {/* Compact Footer Actions */}
                <div className="flex items-center justify-between gap-1">
                    {/* Status Pillars */}
                    <div className="flex gap-2">
                        {/* QA Status */}
                        <div
                            onClick={(e) => { e.stopPropagation(); onQA && onQA(ticket); }}
                            className={clsx(
                                "relative p-[2px] rounded cursor-pointer overflow-hidden transition-all hover:brightness-110 active:scale-95",
                                ticket.qaProgress > 0 && "shadow-[0_0_15px_rgba(74,222,128,0.4)]"
                            )}
                            style={{
                                background: `conic-gradient(from 0deg, #22c55e ${ticket.qaProgress}%, #374151 0)`
                            }}
                            title={`Progreso QA: ${ticket.qaProgress}%`}
                        >
                            <div className={clsx(
                                "px-1.5 py-0.5 rounded-[calc(0.25rem-1.5px)] text-[9px] font-bold flex items-center gap-1 h-full",
                                ticket.qaProgress === 100 ? "bg-green-900/60 text-green-400" : "bg-gray-800 text-gray-400"
                            )}>
                                <CheckSquare className="w-2.5 h-2.5" />
                                QA {ticket.qaProgress === 100 ? 'OK' : `${ticket.qaProgress}%`}
                            </div>
                        </div>

                        {/* Info Status */}
                        <div
                            onClick={(e) => { e.stopPropagation(); onInfo && onInfo(ticket); }}
                            className="relative p-[1.5px] rounded cursor-pointer overflow-hidden transition-all hover:brightness-110 active:scale-95"
                            style={{
                                background: `conic-gradient(from 0deg, #4ade80 ${infoProgress}%, #374151 0)`
                            }}
                            title={`Ficha Técnica: ${infoProgress}%`}
                        >
                            <div className={clsx(
                                "px-1.5 py-0.5 rounded-[calc(0.25rem-1.5px)] text-[9px] font-bold flex items-center gap-1 h-full",
                                infoComplete ? "bg-blue-900/60 text-blue-400" : "bg-gray-800 text-gray-400"
                            )}>
                                <FileText className="w-2.5 h-2.5" />
                                INFO
                            </div>
                        </div>

                        {/* Dispatch Status (Only in Despacho Area) */}
                        {/* Dispatch Status (Only in Despacho Area) */}
                        {isDespacho && (
                            <div
                                onClick={(e) => { e.stopPropagation(); onDispatch && onDispatch(ticket); }}
                                className="relative p-[1.5px] rounded cursor-pointer overflow-hidden transition-all hover:brightness-110 active:scale-95 bg-gray-800"
                                title="Ficha Despacho"
                            >
                                <div className="px-1.5 py-0.5 rounded-[calc(0.25rem-1.5px)] text-[9px] font-bold flex items-center gap-1 h-full bg-orange-900/40 text-orange-400 border border-orange-500/30">
                                    <Truck className="w-2.5 h-2.5" />
                                    DESP
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Move Button */}
                    <button
                        onClick={(e) => { e.stopPropagation(); onMove && onMove(ticket); }}
                        className="p-1 rounded bg-gray-700 text-gray-400 hover:bg-blue-600 hover:text-white transition-colors"
                    >
                        <ArrowRight className="w-3 h-3" />
                    </button>
                </div>
            </div>

            {/* SLA Footer (Interactive) - COMPACT */}
            {isSlaApplicable && (
                <div
                    onClick={(e) => { e.stopPropagation(); onSLA && onSLA(ticket); }}
                    className={clsx("px-3 py-1 flex justify-between items-center text-[9px] uppercase font-bold tracking-wider rounded-b-lg border-t cursor-pointer hover:brightness-110 transition-all",
                        slaStatus === 'danger' ? "bg-red-900/30 border-red-500/30 text-red-400" :
                            slaStatus === 'warning' ? "bg-amber-900/30 border-amber-500/30 text-amber-400" :
                                "bg-blue-900/20 border-blue-500/20 text-blue-400" // Normal/OK Status
                    )}>
                    <div className="flex items-center gap-1.5">
                        <Clock className="w-3 h-3" />
                        <span>{slaStatus === 'danger' ? 'VENCIDO HACE' : (slaStatus === 'warning' ? 'VENCE EN' : 'TIEMPO RESTANTE')}</span>
                    </div>
                    <span className="bg-black/20 px-1.5 py-0.5 rounded shadow-sm">
                        {/* Logic for humanizing remaining or elapsed overdue */}
                        {(() => {
                            // If danger/overdue: Show how much time PAST the limit (elapsed - limit)
                            // If OK/Warning: Show REMAINING time (limit - elapsed)
                            const { limit, elapsed } = getSLAStatus(ticket);
                            const diff = slaStatus === 'danger' ? (elapsed - limit) : (limit - elapsed);

                            const hours = Math.floor(Math.abs(diff) / (1000 * 60 * 60));
                            const days = Math.floor(hours / 24);

                            if (days >= 1) return `${days}d ${hours % 24}h`;
                            return `${hours}h`;
                        })()}
                    </span>
                </div>
            )}
        </div >
    );
});

export default TicketCard;
