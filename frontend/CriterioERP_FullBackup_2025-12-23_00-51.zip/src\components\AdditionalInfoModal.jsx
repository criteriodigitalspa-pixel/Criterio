
import { useState, useEffect } from 'react';
import { useFinancials } from '../hooks/useFinancials';
import { X, Save, AlertTriangle, Check, Smartphone, Cpu, CircuitBoard, HardDrive, Monitor, Battery, Hash, RotateCcw, ArrowRight, AlertCircle, RefreshCw, CheckCircle, Info, CreditCard, Zap, Printer } from 'lucide-react';
import { ticketService } from '../services/ticketService';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import clsx from 'clsx';

// --- DATA OPTIONS (Keep existing constants) ---
const SCREEN_SIZES = ["11.6\"", "12.5\"", "13.3\"", "14.0\"", "15.6\"", "16.0\"", "17.3\""];
const RESOLUTIONS = ["HD (1366x768)", "HD+ (1600x900)", "FHD (1920x1080)", "2K (2560x1440)", "4K (3840x2160)", "Retina"];
const BATTERY_HEALTH = ["0-20% (Mala)", "21-40% (Regular)", "41-60% (Aceptable)", "61-80% (Buena)", "81-100% (Excelente)"];

import { PROCESSORS, GPUS } from '../data/hardware-constants';
import StorageForm from './modals/additional-info/StorageForm';
import CpuGpuForm from './modals/additional-info/CpuGpuForm';

// Required fields
const REQUIRED_FIELDS = ['screenSize', 'screenRes', 'cpuBrand', 'cpuGen', 'gpuBrand', 'gpuModel', 'batteryHealth', 'serialNumber'];

export default function AdditionalInfoModal({ ticket, onClose, onUpdate }) {
    const { user } = useAuth();
    const { getRamPrice } = useFinancials();
    // Local state
    // Normalize info vs ticket top-level fields for the editing form
    const [info, setInfo] = useState({
        ...ticket.additionalInfo,
        marca: ticket.marca || '',
        modelo: ticket.modelo || '',
        precioCompra: ticket.precioCompra || '',
        costosExtra: ticket.costosExtra || '',
        proveedor: ticket.proveedor || ''
    } || {});
    // RAM & Disk State - Robust Initialization with "Blank on First Edit" logic
    const [ram, setRam] = useState(() => {
        // If we have an 'original' snapshot, it means we are editing previously saved technical info. Load it.
        if (ticket.ram?.original) {
            const r = ticket.ram || {};
            return {
                slots: typeof r.slots === 'number' ? r.slots : (Array.isArray(r.detalles) ? r.detalles.length : 0),
                detalles: Array.isArray(r.detalles) ? r.detalles : []
            };
        }
        // If NO 'original', it's the first time entering Technical Info. Start Blank to force verification.
        return { slots: 0, detalles: [] };
    });

    const [disk, setDisk] = useState(() => {
        if (ticket.disco?.original) {
            const d = ticket.disco || {};
            return {
                slots: typeof d.slots === 'number' ? d.slots : (Array.isArray(d.detalles) ? d.detalles.length : 0),
                detalles: Array.isArray(d.detalles) ? d.detalles : []
            };
        }
        return { slots: 0, detalles: [] };
    });

    const [saving, setSaving] = useState(false);
    const [lastSaved, setLastSaved] = useState({
        info: ticket.additionalInfo || {},
        ram: ticket.ram?.original ? (ticket.ram || {}) : { slots: 0, detalles: [] },
        disk: ticket.disco?.original ? (ticket.disco || {}) : { slots: 0, detalles: [] }
    });

    // derived states...
    const [cpuModelOptions, setCpuModelOptions] = useState([]);
    const [gpuModelOptions, setGpuModelOptions] = useState([]);

    const RAM_OPTIONS = ["4GB", "8GB", "16GB", "32GB", "64GB", "128GB"];
    const DISK_OPTIONS = ["128GB SSD", "240GB SSD", "256GB SSD", "480GB SSD", "500GB SSD", "512GB SSD", "1TB SSD", "500GB HDD", "1TB HDD"];

    useEffect(() => {
        if (info.cpuBrand && PROCESSORS[info.cpuBrand]) {
            setCpuModelOptions(PROCESSORS[info.cpuBrand]);
        }
        if (info.gpuBrand && GPUS[info.gpuBrand]) {
            setGpuModelOptions(GPUS[info.gpuBrand]);
        }
    }, [info.cpuBrand, info.gpuBrand]);

    // Auto-Save Effect
    useEffect(() => {
        const timer = setTimeout(() => {
            const currentState = { info, ram, disk };
            // Simple comparison - strict equality might fail on new objects but JSON stringify works for simple structures
            const lastState = { info: lastSaved.info, ram: lastSaved.ram, disk: lastSaved.disk };

            if (JSON.stringify(currentState) !== JSON.stringify(lastState)) {
                handleSave(true);
            }
        }, 2000);
        return () => clearTimeout(timer);
    }, [info, ram, disk, lastSaved]);

    const handleChange = (field, value) => {
        let finalValue = value;
        if (['marca', 'modelo', 'serialNumber'].includes(field)) {
            finalValue = value.toUpperCase();
        }
        const newInfo = { ...info, [field]: finalValue };
        if (field === 'cpuBrand') newInfo.cpuGen = '';
        if (field === 'gpuBrand') newInfo.gpuModel = '';
        setInfo(newInfo);
    };

    // --- RAM LOGIC Handlers ---
    const handleRamSlotsChange = (count) => {
        const slots = Number(count);
        setRam(prev => {
            const currentDetalles = Array.isArray(prev.detalles) ? prev.detalles : [];
            return {
                slots: slots,
                detalles: Array(slots).fill('').map((_, i) => currentDetalles[i] || '')
            };
        });
    };

    const handleRamDetailChange = (index, value) => {
        setRam(prev => {
            const newDetalles = [...(prev.detalles || [])];
            newDetalles[index] = value;
            return { ...prev, detalles: newDetalles };
        });
    };

    // --- DISK LOGIC Handlers ---
    const handleDiskSlotsChange = (count) => {
        const slots = Number(count);
        setDisk(prev => {
            const currentDetalles = Array.isArray(prev.detalles) ? prev.detalles : [];
            return {
                slots: slots,
                detalles: Array(slots).fill('').map((_, i) => currentDetalles[i] || '')
            };
        });
    };

    const handleDiskDetailChange = (index, value) => {
        setDisk(prev => {
            const newDetalles = [...(prev.detalles || [])];
            newDetalles[index] = value;
            return { ...prev, detalles: newDetalles };
        });
    };

    const checkCompletion = (data) => {
        return REQUIRED_FIELDS.every(field => data[field] && data[field].trim() !== '');
    };

    // Helper for visual feedback
    const isPending = (field) => REQUIRED_FIELDS.includes(field) && !info[field];

    const getInputClass = (field, baseClass = "") => {
        const pending = isPending(field);
        return clsx(
            baseClass,
            pending
                ? "border-red-500 ring-2 ring-red-500/50 bg-red-900/20 animate-pulse"
                : "bg-gray-900 border-gray-600 focus:ring-blue-500"
        );
    };

    const handleSave = async (isAuto = false) => {
        if (!ticket.id) return;

        try {
            if (!isAuto) setSaving(true);
            const isComplete = checkCompletion(info);

            // Sanitize info object
            const safeInfo = { ...info };

            // Extract core fields to update at root level
            const { marca, modelo, precioCompra, ...restInfo } = safeInfo;

            Object.keys(restInfo).forEach(key => {
                if (restInfo[key] === undefined) restInfo[key] = '';
            });

            // PRESERVATION LOGIC
            const updates = {
                marca: marca,
                modelo: modelo,
                precioCompra: precioCompra,
                costosExtra: safeInfo.costosExtra,
                additionalInfo: restInfo,
                additionalInfoComplete: isComplete,
                ram: { ...ram },
                disco: { ...disk }
            };

            // RAM Original Logic
            // RAM Original Logic: if missing, snapshot current as original.
            if (!ticket.ram?.original) {
                // If we are changing it now? OR do we just snapshot what was in DB?
                // Snapshot what was in DB.
                const oldRamStr = Array.isArray(ticket.ram?.detalles) ? ticket.ram.detalles.join(' + ') : (ticket.ram?.detalles || '');
                updates.ram.original = oldRamStr;
            } else {
                // Keep existing original
                updates.ram.original = ticket.ram.original;
            }

            // Disk Original Logic
            if (!ticket.disco?.original) {
                const oldDiskStr = Array.isArray(ticket.disco?.detalles) ? ticket.disco.detalles.join(' + ') : (ticket.disco?.detalles || '');
                updates.disco.original = oldDiskStr;
            } else {
                updates.disco.original = ticket.disco.original;
            }

            await ticketService.updateTicket(ticket.id, updates, {
                userId: user.uid,
                reason: 'Technical Info Update',
                snapshot: { preParams: ticket.additionalInfo }
            });

            setLastSaved({ info: safeInfo, ram: updates.ram, disk: updates.disco });

            if (typeof onUpdate === 'function') {
                onUpdate({ ...ticket, ...updates });
            }

            if (!isAuto) {
                toast.success(isComplete ? "Info Guardada Completa" : "Avance Guardado");
                onClose();
            }
        } catch (error) {
            console.error(error);
            if (!isAuto) toast.error("Error al guardar");
        } finally {
            if (!isAuto) setSaving(false);
        }
    };

    const isComplete = checkCompletion(info);

    // Calculate Progress Percentage for simple bar
    const filledCount = REQUIRED_FIELDS.filter(field => info[field] && info[field].trim() !== '').length;
    const progress = Math.round((filledCount / REQUIRED_FIELDS.length) * 100);

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-gray-800 rounded-3xl shadow-2xl border border-gray-700 w-full max-w-2xl overflow-hidden animate-in zoom-in-95 duration-200 relative flex flex-col max-h-[90vh]">

                {/* Header (Same as QA) */}
                <div className="p-6 border-b border-gray-700/50 flex justify-between items-center bg-gray-800/80">
                    <div>
                        <h2 className="text-xl font-bold text-white flex items-center gap-2">
                            <Info className="text-blue-400" /> Información Técnica
                        </h2>
                        <p className="text-sm text-gray-400">Progreso actual: {progress}%</p>
                    </div>

                    <div className="flex items-center gap-2">
                        {/* Print Technical Label */}
                        <button
                            onClick={() => {
                                toast.promise(ticketService.printLabel(ticket, 'technical'), {
                                    loading: 'Enviando a impresora técnica...',
                                    success: '¡Enviado!',
                                    error: 'Error al imprimir'
                                });
                            }}
                            title="Imprimir Ficha Técnica (50x70)"
                            className="p-2 bg-blue-900/30 hover:bg-blue-500/20 rounded-full text-blue-400 hover:text-blue-300 transition-colors border border-blue-500/30"
                        >
                            <Printer className="w-5 h-5" />
                        </button>

                        {/* Close without saving */}
                        <button onClick={onClose} title="Cancelar" className="p-2 hover:bg-red-500/20 rounded-full text-gray-400 hover:text-red-400 transition-colors">
                            <X className="w-6 h-6" />
                        </button>
                    </div>
                </div>

                {/* Progress Bar (Simple Gradient like QA) */}
                <div className="h-1.5 bg-gray-700 w-full">
                    <div
                        className="h-full bg-gradient-to-r from-blue-500 to-green-500 transition-all duration-500"
                        style={{ width: `${progress}% ` }}
                    />
                </div>

                {/* Form Content */}
                <div className="p-6 overflow-y-auto space-y-6 custom-scrollbar flex-1">

                    {/* BASIC INFO CORRECTION Section (New) */}
                    <div className="bg-blue-900/10 p-4 rounded-2xl border border-blue-700/30 grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="col-span-1 md:col-span-2">
                            <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Número de Serie (S/N)</label>
                            <input
                                type="text"
                                value={info.serialNumber || ''}
                                onChange={(e) => handleChange('serialNumber', e.target.value)}
                                placeholder="Escanea o escribe el S/N..."
                                className={getInputClass('serialNumber', "w-full border rounded-xl p-2.5 text-white outline-none focus:ring-2 transition-all font-mono tracking-wider")}
                            />
                        </div>
                        <div className="col-span-1">
                            <label className="block text-xs font-bold text-blue-400 uppercase mb-1">Marca</label>
                            <input
                                type="text"
                                value={info.marca || ''}
                                onChange={(e) => handleChange('marca', e.target.value)}
                                className="w-full bg-gray-900 border border-gray-600 rounded-xl p-2.5 text-white focus:ring-2 ring-blue-500 outline-none"
                            />
                        </div>
                        <div className="col-span-1">
                            <label className="block text-xs font-bold text-blue-400 uppercase mb-1">Modelo</label>
                            <input
                                type="text"
                                value={info.modelo || ''}
                                onChange={(e) => handleChange('modelo', e.target.value)}
                                className="w-full bg-gray-900 border border-gray-600 rounded-xl p-2.5 text-white focus:ring-2 ring-blue-500 outline-none"
                            />
                        </div>
                        <div className="col-span-1">
                            <label className="block text-xs font-bold text-green-400 uppercase mb-1">Precio Compra</label>
                            <div className="relative">
                                <span className="absolute left-3 top-2.5 text-gray-500">$</span>
                                <input
                                    type="number"
                                    value={info.precioCompra || ''}
                                    onChange={(e) => handleChange('precioCompra', e.target.value)}
                                    className="w-full bg-gray-900 border border-gray-600 rounded-xl pl-6 pr-2.5 py-2.5 text-white focus:ring-2 ring-green-500 outline-none font-mono"
                                />
                            </div>
                        </div>
                        <div className="col-span-1">
                            <label className="block text-xs font-bold text-purple-400 uppercase mb-1">Proveedor</label>
                            <input
                                type="text"
                                value={info.proveedor || ''}
                                onChange={(e) => handleChange('proveedor', e.target.value)}
                                className="w-full bg-gray-900 border border-gray-600 rounded-xl p-2.5 text-white focus:ring-2 ring-purple-500 outline-none"
                            />
                        </div>
                        <div className="col-span-1">
                            <label className="block text-xs font-bold text-yellow-500 uppercase mb-1">Costos Extra</label>
                            <div className="relative">
                                <span className="absolute left-3 top-2.5 text-gray-500">$</span>
                                <input
                                    type="number"
                                    value={info.costosExtra || ''}
                                    onChange={(e) => handleChange('costosExtra', e.target.value)}
                                    className="w-full bg-gray-900 border border-gray-600 rounded-xl pl-6 pr-2.5 py-2.5 text-white focus:ring-2 ring-yellow-500 outline-none font-mono"
                                />
                            </div>
                        </div>
                    </div>

                    {/* RAM & Disk Section (New) */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-900/30 p-4 rounded-2xl border border-gray-700/50">
                        {/* RAM */}
                        <div className="space-y-3">
                            <label className="text-xs font-bold text-gray-400 uppercase flex items-center gap-2">
                                <Cpu className="w-4 h-4 text-green-400" /> Memoria RAM
                            </label>
                            <div className="flex gap-2 mb-2">
                                {[0, 1, 2, 4].map(num => (
                                    <button
                                        key={num}
                                        type="button"
                                        onClick={() => handleRamSlotsChange(num)}
                                        className={clsx(
                                            "flex-1 py-1.5 rounded-lg text-xs font-bold transition-all border",
                                            ram.slots === num
                                                ? "bg-green-500/20 border-green-500 text-green-400"
                                                : "bg-gray-800 border-gray-700 text-gray-500 hover:border-gray-600"
                                        )}
                                    >
                                        {num}
                                    </button>
                                ))}
                            </div>
                            <div className="space-y-2">
                                {Array.from({ length: ram.slots }).map((_, i) => (
                                    <select
                                        key={i}
                                        value={ram.detalles[i] || ''}
                                        onChange={(e) => handleRamDetailChange(i, e.target.value)}
                                        className="w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-xs text-white outline-none focus:border-green-500"
                                    >
                                        <option value="">Seleccionar...</option>
                                        {RAM_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                    </select>
                                ))}
                                {ram.slots === 0 && <div className="text-[10px] text-gray-600 italic text-center py-2">Sin RAM (Onboard/Mac)</div>}
                            </div>
                        </div>

                        {/* Disk */}
                        <div className="space-y-3">
                            <label className="text-xs font-bold text-gray-400 uppercase flex items-center gap-2">
                                <CreditCard className="w-4 h-4 text-orange-400" /> Almacenamiento
                            </label>
                            <div className="flex gap-2 mb-2">
                                {[0, 1, 2].map(num => (
                                    <button
                                        key={num}
                                        type="button"
                                        onClick={() => handleDiskSlotsChange(num)}
                                        className={clsx(
                                            "flex-1 py-1.5 rounded-lg text-xs font-bold transition-all border",
                                            disk.slots === num
                                                ? "bg-orange-500/20 border-orange-500 text-orange-400"
                                                : "bg-gray-800 border-gray-700 text-gray-500 hover:border-gray-600"
                                        )}
                                    >
                                        {num}
                                    </button>
                                ))}
                            </div>
                            <div className="space-y-2">
                                {Array.from({ length: disk.slots }).map((_, i) => (
                                    <div key={i} className="relative">
                                        <input
                                            list={`disk-options-modal-${i}`}
                                            type="text"
                                            value={disk.detalles[i] || ''}
                                            onChange={(e) => handleDiskDetailChange(i, e.target.value)}
                                            className="w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-xs text-white outline-none focus:border-orange-500 placeholder-gray-600"
                                            placeholder="Ej: 512GB SSD"
                                        />
                                        <datalist id={`disk-options-modal-${i}`}>
                                            {DISK_OPTIONS.map(opt => <option key={opt} value={opt} />)}
                                        </datalist>
                                    </div>
                                ))}
                                {disk.slots === 0 && <div className="text-[10px] text-gray-600 italic text-center py-2">Sin Disco Extraíble</div>}
                            </div>
                        </div>
                    </div>

                    {/* Screen Section */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="col-span-1">
                            <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Tamaño Pantalla</label>
                            <select
                                value={info.screenSize || ''}
                                onChange={(e) => handleChange('screenSize', e.target.value)}
                                className={getInputClass('screenSize', "w-full border rounded-xl p-2.5 text-white outline-none focus:ring-2 transition-all")}
                            >
                                <option value="" className="bg-gray-900 text-white">Seleccionar...</option>
                                {SCREEN_SIZES.map(s => <option key={s} value={s} className="bg-gray-900 text-white">{s}</option>)}
                            </select>
                        </div>
                        <div className="col-span-1">
                            <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Resolución</label>
                            <select
                                value={info.screenRes || ''}
                                onChange={(e) => handleChange('screenRes', e.target.value)}
                                className={getInputClass('screenRes', "w-full border rounded-xl p-2.5 text-white outline-none focus:ring-2 transition-all")}
                            >
                                <option value="" className="bg-gray-900 text-white">Seleccionar...</option>
                                {RESOLUTIONS.map(r => <option key={r} value={r} className="bg-gray-900 text-white">{r}</option>)}
                            </select>
                        </div>
                    </div>

                    {/* CPU Section */}
                    <div className="bg-gray-700/20 p-4 rounded-xl border border-gray-700/50">
                        <div className="flex items-center gap-2 mb-3 text-gray-300 font-bold">
                            <Cpu className="w-4 h-4 text-cyan-400" /> Procesador
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Procesador (Marca)</label>
                                <select
                                    value={info.cpuBrand || ''}
                                    onChange={(e) => handleChange('cpuBrand', e.target.value)}
                                    className={getInputClass('cpuBrand', "w-full border rounded-xl p-2.5 text-white outline-none focus:ring-2 transition-all")}
                                >
                                    <option value="" className="bg-gray-900 text-white">Seleccionar Marca...</option>
                                    {Object.keys(PROCESSORS).map(p => <option key={p} value={p} className="bg-gray-900 text-white">{p}</option>)}
                                </select>
                            </div>
                            <div className="col-span-1">
                                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Generación / Serie</label>
                                <select
                                    value={info.cpuGen || ''}
                                    onChange={(e) => handleChange('cpuGen', e.target.value)}
                                    disabled={!info.cpuBrand}
                                    className={getInputClass('cpuGen', "w-full border rounded-xl p-2.5 text-white outline-none focus:ring-2 transition-all disabled:opacity-50")}
                                >
                                    <option value="" className="bg-gray-900 text-white">Seleccionar Generación...</option>
                                    {info.cpuBrand && PROCESSORS[info.cpuBrand]?.map(g => (
                                        <option key={g} value={g} className="bg-gray-900 text-white">{g}</option>
                                    ))}
                                </select>
                            </div>

                            {/* GPU */}
                            <div className="col-span-1">
                                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Gráficos (Marca)</label>
                                <select
                                    value={info.gpuBrand || ''}
                                    onChange={(e) => handleChange('gpuBrand', e.target.value)}
                                    className={getInputClass('gpuBrand', "w-full border rounded-xl p-2.5 text-white outline-none focus:ring-2 transition-all")}
                                >
                                    <option value="" className="bg-gray-900 text-white">Seleccionar Marca...</option>
                                    {Object.keys(GPUS).map(g => <option key={g} value={g} className="bg-gray-900 text-white">{g}</option>)}
                                </select>
                            </div>
                            <div className="col-span-1">
                                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Modelo GPU</label>
                                {info.gpuBrand === 'Otros' ? (
                                    <input
                                        type="text"
                                        value={info.gpuModel || ''}
                                        onChange={(e) => handleChange('gpuModel', e.target.value)}
                                        placeholder="Especifique modelo..."
                                        className={getInputClass('gpuModel', "w-full border rounded-xl p-2.5 text-white outline-none focus:ring-2 transition-all placeholder:text-gray-600")}
                                        autoFocus
                                    />
                                ) : (
                                    <select
                                        value={info.gpuModel || ''}
                                        onChange={(e) => handleChange('gpuModel', e.target.value)}
                                        disabled={!info.gpuBrand}
                                        className={getInputClass('gpuModel', "w-full border rounded-xl p-2.5 text-white outline-none focus:ring-2 transition-all disabled:opacity-50")}
                                    >
                                        <option value="" className="bg-gray-900 text-white">Seleccionar Modelo...</option>
                                        {info.gpuBrand && GPUS[info.gpuBrand]?.map(m => (
                                            <option key={m} value={m} className="bg-gray-900 text-white">{m}</option>
                                        ))}
                                    </select>
                                )}
                            </div>
                        </div>

                        {/* Battery Legacy Section */}
                        <div className="grid grid-cols-1 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-400 uppercase mb-1 flex items-center gap-1"><Zap className="w-3 h-3 text-yellow-500" /> Salud Batería</label>
                                <select
                                    value={info.batteryHealth || ''}
                                    onChange={(e) => handleChange('batteryHealth', e.target.value)}
                                    className="w-full bg-gray-900 border border-gray-600 rounded-xl p-2.5 text-white focus:ring-2 ring-yellow-500 outline-none"
                                >
                                    <option value="" className="bg-gray-900 text-white">Estado...</option>
                                    {BATTERY_HEALTH.map(b => <option key={b} value={b} className="bg-gray-900 text-white">{b}</option>)}
                                </select>
                            </div>
                        </div>

                    </div>

                    {/* --- RESUMEN FINAL --- */}
                    <div className="bg-gray-800/80 p-5 rounded-2xl border border-gray-700/50 mb-6 backdrop-blur-sm">
                        <div className="flex items-center gap-2 mb-4 text-white font-bold text-lg border-b border-gray-700 pb-2">
                            <CheckCircle className="text-green-500 w-5 h-5" /> Resumen de Cierre
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* 1. Basic Identity */}
                            <div className="space-y-3">
                                <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Equipo</div>
                                <div className="flex items-center gap-3 bg-gray-900/50 p-3 rounded-lg border border-gray-700/50">
                                    <Smartphone className="text-blue-400 w-5 h-5" />
                                    <div>
                                        <div className="text-sm font-bold text-white">{info.marca} {info.modelo}</div>
                                        <div className="text-xs text-blue-300 font-mono">{info.cpuBrand} {info.cpuGen}</div>
                                    </div>
                                </div>
                            </div>

                            {/* 2. Changes Summary (RAM & Disk) */}
                            <div className="space-y-2">
                                <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Modificaciones de Hardware</div>

                                {/* RAM Comparison */}
                                {(() => {
                                    // 1. Get String Representations
                                    const origVal = ticket.ram?.original ?? (ticket.ram?.detalles?.join(' + ') || 'N/A');
                                    const currVal = ram.detalles?.filter(Boolean).join(' + ') || 'N/A';
                                    const changed = origVal !== currVal;

                                    // 2. Calculate Financials
                                    const parseAndSum = (str) => {
                                        if (!str || str === 'N/A') return 0;
                                        return str.split('+').reduce((sum, item) => sum + getRamPrice(item.trim()), 0);
                                    };

                                    const oldPrice = parseAndSum(origVal);
                                    const newPrice = parseAndSum(currVal);
                                    const diff = newPrice - oldPrice;

                                    return (
                                        <div className={clsx("flex items-center justify-between p-2.5 rounded-lg border transition-colors", changed ? "bg-amber-900/20 border-amber-500/50" : "bg-gray-900/50 border-gray-700/50")}>
                                            <div className="flex items-center gap-2">
                                                <CircuitBoard className={clsx("w-4 h-4", changed ? "text-amber-400" : "text-gray-500")} />
                                                <span className="text-xs font-bold text-gray-400">RAM</span>
                                            </div>

                                            <div className="flex flex-col items-end">
                                                <div className="flex items-center gap-3 text-sm">
                                                    {changed ? (
                                                        <>
                                                            <span className="text-gray-500 line-through text-xs">{origVal}</span>
                                                            <ArrowRight className="w-3 h-3 text-amber-500" />
                                                            <span className="text-amber-300 font-bold">{currVal}</span>
                                                        </>
                                                    ) : (
                                                        <span className="text-gray-300">{currVal}</span>
                                                    )}
                                                </div>
                                                {/* Price Differential */}
                                                {changed && diff !== 0 && (
                                                    <div className={clsx("text-[10px] font-mono mt-1 px-1.5 py-0.5 rounded", diff > 0 ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400")}>
                                                        {diff > 0 ? '+' : ''} ${diff.toLocaleString()}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })()}

                                {/* Disk Comparison */}
                                {(() => {
                                    const origVal = ticket.disco?.original ?? (ticket.disco?.detalles?.join(' + ') || 'N/A');
                                    const currVal = disk.detalles?.filter(Boolean).join(' + ') || 'N/A';
                                    const changed = origVal !== currVal;

                                    return (
                                        <div className={clsx("flex items-center justify-between p-2.5 rounded-lg border transition-colors", changed ? "bg-purple-900/20 border-purple-500/50" : "bg-gray-900/50 border-gray-700/50")}>
                                            <div className="flex items-center gap-2">
                                                <HardDrive className={clsx("w-4 h-4", changed ? "text-purple-400" : "text-gray-500")} />
                                                <span className="text-xs font-bold text-gray-400">Disco</span>
                                            </div>

                                            <div className="flex items-center gap-3 text-sm">
                                                {changed ? (
                                                    <>
                                                        <span className="text-gray-500 line-through text-xs">{origVal}</span>
                                                        <ArrowRight className="w-3 h-3 text-purple-500" />
                                                        <span className="text-purple-300 font-bold">{currVal}</span>
                                                    </>
                                                ) : (
                                                    <span className="text-gray-300">{currVal}</span>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })()}
                            </div>
                        </div>
                    </div>

                    {/* Footer Buttons (Standard) */}
                    <div className="p-5 bg-gray-900/50 border-t border-gray-700/50 flex flex-col items-center gap-2">
                        <button
                            onClick={() => handleSave(false)}
                            disabled={saving}
                            className={clsx(
                                "w-full py-3.5 rounded-xl font-bold text-lg shadow-lg transition-all active:scale-[0.98] flex justify-center items-center gap-2",
                                isComplete
                                    ? "bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white shadow-green-500/20"
                                    : "bg-gray-700 hover:bg-gray-600 text-gray-200"
                            )}
                        >
                            {saving ? "Guardando..." : isComplete ? "Guardar y Continuar" : "Continuar Después"}
                        </button>
                        {!isComplete && <p className="text-gray-500 text-xs">Completa los campos requeridos para finalizar.</p>}
                    </div>
                </div>
            </div>
        </div>
    );
}
