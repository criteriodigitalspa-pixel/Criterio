import { useState, useEffect } from 'react';
import { X, Save, Truck, User, Phone, Mail, Calendar, Clock, MapPin, FileText, CheckCircle, DollarSign, Tag, Search, Database } from 'lucide-react';
import { ticketService } from '../services/ticketService';
import { clientService } from '../services/clientService'; // Import Service
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import clsx from 'clsx';

export default function DispatchModal({ ticket, onClose, onUpdate }) {
    const { user } = useAuth();

    // Helper to filter out placeholder names like "Stock / Compra"
    const getSafeClientName = (name) => {
        if (!name) return '';
        if (name.includes('Stock / Compra')) return '';
        return name;
    };

    const initialClientName = getSafeClientName(ticket.nombreCliente);

    // UI Mode State
    const [clientMode, setClientMode] = useState(initialClientName ? 'EXISTING' : 'NEW');
    const [searchTerm, setSearchTerm] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [isSearching, setIsSearching] = useState(false);
    const [saveToDb, setSaveToDb] = useState(true); // Default save new clients

    // 1. Client Info State
    const [clientInfo, setClientInfo] = useState({
        nombreCliente: initialClientName,
        clientAlias: ticket.clientAlias || '',
        clientEmail: ticket.clientEmail || '',
        clientPhone: ticket.clientPhone || '',
        clientRut: ticket.clientRut || '',
        clientAddress: ticket.clientAddress || ''
    });

    // 2. Dispatch Details State
    const [dispatchDetails, setDispatchDetails] = useState({
        dispatchDay: ticket.dispatchDay || '',
        dispatchHour: ticket.dispatchHour || '',
        dispatchAddress: ticket.dispatchAddress || '',
        dispatchNotes: ticket.dispatchNotes || '',
        isReserved: ticket.isReserved || false
    });

    // 3. Price State
    const [price, setPrice] = useState(ticket.precioVenta || '');

    const [saving, setSaving] = useState(false);

    // Handlers
    const handleClientChange = (field, value) => {
        setClientInfo(prev => ({ ...prev, [field]: value }));
    };

    const handleDetailChange = (field, value) => {
        setDispatchDetails(prev => ({ ...prev, [field]: value }));
    };

    const handleCheckboxChange = (field) => {
        setDispatchDetails(prev => ({ ...prev, [field]: !prev[field] }));
    };

    // Client Search Logic
    const handleSearch = async (term) => {
        if (term.length < 2) {
            setSearchResults([]);
            return;
        }
        setIsSearching(true);
        try {
            const results = await clientService.searchClients(term);
            setSearchResults(results);
        } catch (error) {
            console.error(error);
        } finally {
            setIsSearching(false);
        }
    };

    const selectClient = (client) => {
        setClientInfo({
            nombreCliente: client.name || '',
            clientAlias: client.alias || '',
            clientEmail: client.email || '',
            clientPhone: client.phone || '',
            clientRut: client.rut || '',
            clientAddress: client.address || ''
        });
        setSearchTerm(''); // Clear search input visually
        setSearchResults([]);
    };

    // Derived Validation for "Vendido"
    const isValidForSold = clientInfo.nombreCliente?.trim().length > 0 && Number(price) > 0;

    const handleSave = async (actionType = 'SAVE') => {
        if (!ticket.id) return;
        setSaving(true);
        const toastId = toast.loading(actionType === 'SOLD' ? "Procesando Venta..." : "Guardando...");

        try {
            // STEP 0: Auto-Save Client if NEW and Checkbox checked
            if (clientMode === 'NEW' && saveToDb && clientInfo.nombreCliente) {
                try {
                    await clientService.createClient({
                        name: clientInfo.nombreCliente,
                        rut: clientInfo.clientRut || '',
                        phone: clientInfo.clientPhone || '',
                        email: clientInfo.clientEmail || '',
                        address: clientInfo.clientAddress || '',
                        alias: clientInfo.clientAlias || ''
                    });
                } catch (clientErr) {
                    console.error("Failed to save client DB", clientErr);
                }
            }

            const updates = {
                ...clientInfo,
                ...dispatchDetails,
                precioVenta: Number(price)
            };

            // Logic for 'Vendido' action
            if (actionType === 'SOLD') {
                updates.status = 'Closed';
                updates.currentArea = 'Ventas'; // Move to Sales Module
                updates.soldAt = new Date().toISOString();
                updates.soldBy = user.uid;
                updates.isSold = true;

                // Financial Calculations
                const salePrice = Number(price) || 0;
                const purchasePrice = Number(ticket.precioCompra) || 0;
                const extraCosts = Number(ticket.costosExtra) || 0;
                const partsCost = Number(ticket.reparacion?.costoRepuestos) || 0;

                const totalCost = purchasePrice + extraCosts + partsCost;

                // Simplified Tax Logic (Net Basis):
                const netSale = Math.round(salePrice / 1.19);
                const ivaDebit = salePrice - netSale;
                const grossMargin = netSale - totalCost;

                updates.financials = {
                    salePrice,
                    purchasePrice,
                    extraCosts,
                    partsCost,
                    totalCost,
                    netSale,
                    ivaDebit,
                    grossMargin,
                    taxRate: 0.19
                };
            }

            await ticketService.updateTicket(ticket.id, updates, {
                userId: user.uid,
                reason: actionType === 'SOLD' ? 'Venta Finalizada - Movido a Ventas' : 'Dispatch Info Update',
                changes: updates
            });

            onUpdate({ ...ticket, ...updates });
            toast.success(actionType === 'SOLD' ? "¡Venta Exitosa!" : "Información Guardada", { id: toastId });
            onClose();

        } catch (error) {
            console.error("Save failed", error);
            toast.error("Error al guardar", { id: toastId });
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-gray-800 rounded-3xl shadow-2xl border border-gray-700 w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200 relative flex flex-col max-h-[95vh]">

                {/* Header */}
                <div className="p-6 border-b border-gray-700/50 flex justify-between items-center bg-gray-800/80">
                    <div>
                        <h2 className="text-xl font-bold text-white flex items-center gap-2">
                            <Truck className="text-orange-400" /> Ficha de Despacho
                        </h2>
                        <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs font-mono font-bold bg-gray-700 px-2 py-0.5 rounded text-gray-300">{ticket.ticketId}</span>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-700 rounded-full text-gray-400 hover:text-white transition-colors">
                        <X className="w-6 h-6" />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">

                    {/* Section 1: Client Info */}
                    <div className="bg-gray-900/30 p-4 rounded-2xl border border-gray-700/50 space-y-4">
                        <div className="flex items-center justify-between mb-2">
                            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                                <User className="w-4 h-4" /> Información del Cliente
                            </h3>

                            {/* RESTORED TABS */}
                            <div className="flex bg-gray-800 p-1 rounded-lg border border-gray-700">
                                <button
                                    onClick={() => setClientMode('EXISTING')}
                                    className={clsx("px-3 py-1 text-xs font-bold rounded-md transition-all", clientMode === 'EXISTING' ? "bg-blue-600 text-white shadow-md" : "text-gray-400 hover:text-white")}
                                >
                                    Existente
                                </button>
                                <button
                                    onClick={() => setClientMode('NEW')}
                                    className={clsx("px-3 py-1 text-xs font-bold rounded-md transition-all", clientMode === 'NEW' ? "bg-green-600 text-white shadow-md" : "text-gray-400 hover:text-white")}
                                >
                                    Nuevo
                                </button>
                            </div>
                        </div>

                        {/* EXISTING CLIENT SEARCH */}
                        {clientMode === 'EXISTING' && (
                            <div className="relative z-50">
                                <label className="block text-xs font-bold text-gray-400 mb-1">Buscar Cliente (Nombre)</label>
                                <div className="relative">
                                    <Search className="absolute left-3 top-2.5 w-4 h-4 text-blue-500" />
                                    <input
                                        type="text"
                                        value={searchTerm}
                                        onChange={(e) => {
                                            setSearchTerm(e.target.value);
                                            handleSearch(e.target.value);
                                        }}
                                        className="w-full bg-gray-800 border border-gray-600 rounded-xl pl-9 pr-2.5 py-2.5 text-white focus:ring-2 ring-blue-500 outline-none"
                                        placeholder="Escribe para buscar..."
                                    />
                                    {isSearching && (
                                        <div className="absolute right-3 top-3 w-4 h-4 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin"></div>
                                    )}
                                </div>

                                {/* Autocomplete Dropdown */}
                                {searchResults.length > 0 && (
                                    <div className="absolute top-full left-0 right-0 mt-1 bg-gray-800 border border-gray-700 rounded-xl shadow-2xl overflow-hidden z-50 max-h-48 overflow-y-auto">
                                        {searchResults.map(client => (
                                            <button
                                                key={client.id}
                                                onClick={() => selectClient(client)}
                                                className="w-full text-left px-4 py-3 hover:bg-gray-700/50 flex items-center justify-between group border-b border-gray-700/50 last:border-0"
                                            >
                                                <div>
                                                    <div className="font-bold text-white group-hover:text-blue-400 transition-colors">{client.name}</div>
                                                    <div className="text-xs text-gray-500 flex gap-2">
                                                        <span>{client.phone || 'Sin télefono'}</span>
                                                        <span>•</span>
                                                        <span>{client.email || 'Sin email'}</span>
                                                    </div>
                                                </div>
                                                <CheckCircle className="w-4 h-4 text-gray-600 group-hover:text-blue-500 opacity-0 group-hover:opacity-100 transition-all" />
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </div>
                        )}

                        {/* SELECTED EXISTING CLIENT CARD (Hidden details mode) */}
                        {clientMode === 'EXISTING' && clientInfo.nombreCliente && !searchTerm && (
                            <div className="bg-blue-900/20 border border-blue-500/30 p-3 rounded-xl flex items-center justify-between animate-in fade-in zoom-in-95">
                                <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center font-bold text-white">
                                        {clientInfo.nombreCliente.charAt(0)}
                                    </div>
                                    <div>
                                        <div className="text-sm font-bold text-white">{clientInfo.nombreCliente}</div>
                                        <div className="text-xs text-blue-300 font-mono">Datos cargados de BD</div>
                                    </div>
                                </div>
                                <button onClick={() => {
                                    setClientInfo({ nombreCliente: '', clientEmail: '', clientPhone: '' }); // Clear
                                    setSearchTerm('');
                                }} className="p-1 hover:bg-blue-900/50 rounded-lg text-blue-300 hover:text-white transition-colors">
                                    <X className="w-4 h-4" />
                                </button>
                            </div>
                        )}

                        {/* NEW FORM (Visible if in NEW mode) */}
                        {clientMode === 'NEW' && (
                            <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                                <div className="grid grid-cols-3 gap-4">
                                    <div className="col-span-2">
                                        <label className="block text-xs font-bold text-gray-400 mb-1">Nombre Completo</label>
                                        <input
                                            type="text"
                                            value={clientInfo.nombreCliente}
                                            onChange={(e) => handleClientChange('nombreCliente', e.target.value)}
                                            className="w-full bg-gray-800 border border-gray-600 rounded-xl p-2.5 text-white focus:ring-2 ring-green-500 outline-none"
                                            placeholder="Nombre..."
                                        />
                                    </div>
                                    <div className="col-span-1">
                                        <label className="block text-xs font-bold text-gray-400 mb-1">RUT (Opcional)</label>
                                        <input
                                            type="text"
                                            value={clientInfo.clientRut || ''}
                                            onChange={(e) => handleClientChange('clientRut', e.target.value)}
                                            className="w-full bg-gray-800 border border-gray-600 rounded-xl p-2.5 text-white focus:ring-2 ring-green-500 outline-none"
                                            placeholder="12.345..."
                                        />
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-bold text-gray-400 mb-1">Teléfono</label>
                                        <input
                                            type="tel"
                                            value={clientInfo.clientPhone}
                                            onChange={(e) => handleClientChange('clientPhone', e.target.value)}
                                            className="w-full bg-gray-800 border border-gray-600 rounded-xl p-2.5 text-white focus:ring-2 ring-green-500 outline-none"
                                            placeholder="+56 9..."
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-gray-400 mb-1">Email</label>
                                        <input
                                            type="email"
                                            value={clientInfo.clientEmail}
                                            onChange={(e) => handleClientChange('clientEmail', e.target.value)}
                                            className="w-full bg-gray-800 border border-gray-600 rounded-xl p-2.5 text-white focus:ring-2 ring-green-500 outline-none"
                                            placeholder="email@..."
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-400 mb-1">Dirección</label>
                                    <input
                                        type="text"
                                        value={clientInfo.clientAddress || ''}
                                        onChange={(e) => handleClientChange('clientAddress', e.target.value)}
                                        className="w-full bg-gray-800 border border-gray-600 rounded-xl p-2.5 text-white focus:ring-2 ring-green-500 outline-none"
                                        placeholder="Dirección completa..."
                                    />
                                </div>
                                <div className="flex items-center gap-2 pt-2">
                                    <input
                                        type="checkbox"
                                        id="saveClient"
                                        checked={saveToDb}
                                        onChange={(e) => setSaveToDb(e.target.checked)}
                                        className="w-4 h-4 rounded border-gray-600 text-green-600 focus:ring-green-500 bg-gray-700"
                                    />
                                    <label htmlFor="saveClient" className="text-sm text-gray-300 cursor-pointer select-none">Guardar en Base de Clientes automáticamente</label>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Section 2: Dispatch Logistics */}
                    <div className="bg-gray-900/30 p-4 rounded-2xl border border-gray-700/50 space-y-4">
                        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                            <Truck className="w-4 h-4" /> Logística de Entrega (Opcional)
                        </h3>

                        {/* Day & Hour */}
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-400 mb-1">Día</label>
                                <div className="relative">
                                    <Calendar className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
                                    <input
                                        type="date"
                                        value={dispatchDetails.dispatchDay}
                                        onChange={(e) => handleDetailChange('dispatchDay', e.target.value)}
                                        className="w-full bg-gray-800 border border-gray-600 rounded-xl pl-9 pr-2.5 py-2.5 text-white focus:ring-2 ring-orange-500 outline-none custom-date-input"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-400 mb-1">Hora</label>
                                <div className="relative">
                                    <Clock className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
                                    <input
                                        type="time"
                                        value={dispatchDetails.dispatchHour}
                                        onChange={(e) => handleDetailChange('dispatchHour', e.target.value)}
                                        className="w-full bg-gray-800 border border-gray-600 rounded-xl pl-9 pr-2.5 py-2.5 text-white focus:ring-2 ring-orange-500 outline-none custom-time-input"
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Address */}
                        <div>
                            <label className="block text-xs font-bold text-gray-400 mb-1">Dirección</label>
                            <div className="relative">
                                <MapPin className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
                                <input
                                    type="text"
                                    value={dispatchDetails.dispatchAddress}
                                    onChange={(e) => handleDetailChange('dispatchAddress', e.target.value)}
                                    className="w-full bg-gray-800 border border-gray-600 rounded-xl pl-9 pr-2.5 py-2.5 text-white focus:ring-2 ring-orange-500 outline-none"
                                    placeholder="Dirección de entrega..."
                                />
                            </div>
                        </div>

                        {/* Notes */}
                        <div>
                            <label className="block text-xs font-bold text-gray-400 mb-1">Notas Adicionales</label>
                            <div className="relative">
                                <FileText className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
                                <textarea
                                    value={dispatchDetails.dispatchNotes}
                                    onChange={(e) => handleDetailChange('dispatchNotes', e.target.value)}
                                    className="w-full bg-gray-800 border border-gray-600 rounded-xl pl-9 pr-2.5 py-2.5 text-white focus:ring-2 ring-orange-500 outline-none min-h-[80px] resize-none"
                                    placeholder="Instrucciones especiales..."
                                />
                            </div>
                        </div>

                        {/* Reserved Checkbox */}
                        <div className="flex items-center gap-3 pt-2">
                            <label className="flex items-center gap-2 cursor-pointer group select-none">
                                <div className={clsx(
                                    "w-5 h-5 rounded border flex items-center justify-center transition-colors",
                                    dispatchDetails.isReserved ? "bg-purple-600 border-purple-600" : "bg-gray-800 border-gray-600 group-hover:border-purple-500"
                                )}>
                                    {dispatchDetails.isReserved && <CheckCircle className="w-3.5 h-3.5 text-white" />}
                                    <input
                                        type="checkbox"
                                        className="hidden"
                                        checked={dispatchDetails.isReserved}
                                        onChange={() => handleCheckboxChange('isReserved')}
                                    />
                                </div>
                                <span className={clsx("font-bold text-sm", dispatchDetails.isReserved ? "text-purple-400" : "text-gray-400")}>
                                    Reservado
                                </span>
                            </label>
                        </div>

                    </div>

                    {/* Section 3: Financials */}
                    <div className="bg-gray-900/30 p-4 rounded-2xl border border-gray-700/50">
                        <label className="block text-xs font-bold text-gray-400 mb-1 uppercase">Monto Venta Final</label>
                        <div className="relative">
                            <DollarSign className="absolute left-3 top-2.5 w-4 h-4 text-green-500" />
                            <input
                                type="number"
                                value={price}
                                onChange={(e) => setPrice(e.target.value)}
                                className="w-full bg-gray-800 border border-gray-600 rounded-xl pl-9 pr-2.5 py-2.5 text-green-400 font-mono font-bold text-lg focus:ring-2 ring-green-500 outline-none placeholder-gray-600"
                                placeholder="0"
                            />
                        </div>
                    </div>

                </div>

                {/* Footer */}
                <div className="p-5 bg-gray-900/50 border-t border-gray-700/50 flex flex-col gap-3">

                    {/* Primary Actions */}
                    <div className="flex gap-3">
                        <button
                            onClick={() => handleSave('SAVE')}
                            disabled={saving}
                            className="flex-1 py-3 rounded-xl bg-gray-700 hover:bg-gray-600 text-white font-bold transition-all active:scale-[0.98] flex justify-center items-center gap-2"
                        >
                            <Save className="w-5 h-5" />
                            Guardar Info
                        </button>

                        <button
                            onClick={() => handleSave('SOLD')}
                            disabled={saving || !isValidForSold}
                            className={clsx(
                                "flex-1 py-3 rounded-xl font-bold text-white transition-all active:scale-[0.98] flex justify-center items-center gap-2 shadow-lg",
                                !isValidForSold
                                    ? "bg-gray-800/50 text-gray-500 cursor-not-allowed border border-gray-700"
                                    : "bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 shadow-green-900/20"
                            )}
                            title={!isValidForSold ? "Ingresa Nombre Cliente y Precio para vender" : "Finalizar Venta"}
                        >
                            <CheckCircle className="w-5 h-5" />
                            VENDIDO
                        </button>
                    </div>
                </div>

            </div>
        </div>
    );
}
