# Optimization Protocol: Project "Antigravity" - Phase 4

## 1. Problem Diagnosis
The user reports general slowness across the application:
- Slow tab switching.
- Laggy form inputs (typing delay).
- Slow form submission.
- Heavy load times.

**Root Causes (Hypothesis):**
1.  **Rendering Bottlenecks:** `DashboardLayout` or `KanbanBoard` re-rendering the entire tree on small state changes.
2.  **Large Bundle Size:** Vite warnings indicate chunks > 500kB, meaning all libraries (Firebase, Lucide, Charts) are loading at once.
3.  **Unoptimized Lists:** The Kanban board likely renders hundreds of TicketCard components without virtualization.
4.  **Sync Heavy Operations:** Filtering logic in `useKanban` or `IngresoTicket` running on every keystroke/render without memoization.

## 2. Immediate Action Plan

### A. Code Splitting (Lazy Loading)
Break the monolithic bundle into smaller chunks that load only when needed.

- [ ] **Lazy Routes:** Convert all page imports in `App.jsx` to `React.lazy()`.
    - `Dashboard`
    - `IngresoTicket`
    - `Users`
    - `Settings`
- [ ] **Lazy Components:** Load heavy modals (like `TicketDetailModal` or `BatchPreviewModal`) only when they are opened.

### B. Rendering Optimization (Memoization)
Prevent unnecessary re-renders of heavy components.

- [ ] **TicketCard:** Wrap in `React.memo` (Already done, verify `prevProps` comparison is efficient).
- [ ] **KanbanColumn:** Wrap in `React.memo` to prevent re-rendering *all* columns when dragging in one.
- [ ] **Context Selectors:** Ensure `useAuth` or `useProcessing` updates don't trigger full app re-renders unless necessary.

### C. Input Optimization (Debouncing)
Fix "typing delay".

- [ ] **Search Bars:** Debounce the search input in `FilterBar` (wait 300ms before filtering).
- [ ] **Form Inputs:** Inspect `IngresoTicket` `handleChange`. Ensure it doesn't trigger complex recalculations (like `useEffect` filtering list) on every keypress.

### D. List Virtualization (High Impact)
The Kanban board is likely the heaviest component.

- [ ] **Virtual/Windowed Lists:** If a column has 50+ tickets, only render the 10 visible ones. (Library: `react-window` or `virtua`). *Note: Drag and drop makes this complex, we might skip full virtualization if we can optimize `TicketCard` enough.*

## 3. Implementation Steps

### Step 1: Code Splitting (Lazy Routes)
Edit `src/App.jsx` (or main router file) to implement `Suspense` and `lazy`.

```javascript
const Dashboard = lazy(() => import('./pages/Dashboard'));
const KanbanBoard = lazy(() => import('./components/KanbanBoard'));
// ... inside Routes
<Route path="/dashboard" element={<Suspense fallback={<Loader />}><Dashboard /></Suspense>} />
```

### Step 2: Debounce Search
Modify `useKanban.js` or `FilterBar.jsx`.

### Step 3: Analyze Filters
Move heavy filter logic in `useKanban.js` to `useMemo`.

## 4. Verification
- Use Chrome DevTools Performance Tab to measure "Scripting" time before/after.
- User feedback on "typing feel".
