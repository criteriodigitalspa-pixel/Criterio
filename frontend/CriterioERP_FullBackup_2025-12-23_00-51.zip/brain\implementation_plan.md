# Password Tools and UI Polish Plan

## Goal
Improve User Management UX by adding password generation tools and enhancing user identity display (Alias) across the application.

## User Review Required
- **Password Reset Limitation**: For existing users, we cannot "View" or "Set" the password directly without the old password (client-side limitation). We will add a "Generate Password" button for **New Users** (Create Flow) where it is most useful. for Edit Flow, we will clarify the limitation if needed or explore reset emails.

## Proposed Changes

### 1. `src/pages/Users.jsx` (User Management)
- **Modify `openCreateModal` / Render**:
    - Add a "Generate Password" button next to the password input.
    - Add a "Copy to Clipboard" button.
    - Function: `generatePassword()` -> Returns 12-char strong password.

### 2. `src/layouts/DashboardLayout.jsx` (Sidebar)
- **Modify Footer**:
    - Display `userProfile.displayName` (Alias) instead of Email if available.
    - Fallback to Email if Alias is missing.

### 3. `src/components/dashboard/WelcomeBanner.jsx` (New Component)
- **Create**: A new component to show a personalized welcome message.
    - "Bienvenido, [Alias]"
    - Current Date/Time context maybe?
- **Integrate into `src/pages/Dashboard.jsx`**:
    - Insert at the top of the dashboard.

## Verification
- Create a new user -> Use Generator -> Copy -> Create.
- Login as that user -> Check Sidebar Name.
- Check Dashboard Welcome Message.
