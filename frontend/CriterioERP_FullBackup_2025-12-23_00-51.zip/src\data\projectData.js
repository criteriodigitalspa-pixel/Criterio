export const PROJECT_DATA = {
    done: [
        { id: 'd0', title: 'Inicialización del Proyecto', date: '2025-12-05', desc: 'Setup de React + Vite + Tailwind y Estructura Backend.', details: 'Configuración inicial del repositorio, instalación de dependencias clave (Firebase, Lucide, Router) y establecimiento de la arquitectura de carpetas.' },
        { id: 'd1', title: 'Núcleo Frontend', date: '2025-12-05', desc: 'Configuración de Tailwind, Rutas y Layout Base.', details: 'Creación de Sidebar receptivo, modo oscuro base y sistema de enrutamiento protegido.' },
        { id: 'd2', title: 'Integración Firebase', date: '2025-12-05', desc: 'Inicialización de Firestore y Authentication.', details: 'Conexión a proyecto Firebase, habilitación de proveedores de auth y reglas base.' },
        { id: 'd3', title: 'Autenticación', date: '2025-12-05', desc: 'Login/Registro con Roles (Admin/Técnico).', details: 'Contexto de autenticación global, protección de rutas y manejo de sesión persistente.' },
        { id: 'd4', title: 'Dashboard y Layout', date: '2025-12-05', desc: 'Sidebar responsivo, Modo Oscuro y Branding.', details: 'Diseño de la estructura principal de la aplicación, adaptable a móviles y escritorio.' },
        { id: 'd5', title: 'Sistema Smart ID', date: '2025-12-05', desc: 'IDs autoincrementables (YYMM-XXXX).', details: 'Lógica transaccional en Firestore para generar IDs legibles únicos evitando colisiones.' },
        { id: 'd6', title: 'Gestión de Inventario', date: '2025-12-05', desc: 'CRUD básico para ítems de inventario.', details: 'Tablas de gestión de stock, creación, edición y borrado de productos.' },
        { id: 'd7', title: 'Gestión de Tickets', date: '2025-12-05', desc: 'Esquema avanzado de Ticket y Formularios.', details: 'Estructura de datos compleja (Cliente, Equipo, Ficha Técnica) y formularios dinámicos.' },
        { id: 'd9', title: 'Tablero Kanban', date: '2025-12-05', desc: 'Visualización de flujo de trabajo en 7 Áreas.', details: 'Tablero interactivo con columnas para controlar el estado de cada reparación.' },
        { id: 'd10', title: 'Lógica de Transición', date: '2025-12-05', desc: 'Movimientos, Validaciones y Formularios por Área.', details: 'Motor de reglas para gobernar qué pasa cuando un ticket se mueve de A a B.' },
        { id: 'd11', title: 'Servicios Unificados', date: '2025-12-05', desc: 'Formularios estándar para Servicio Rápido y Dedicado.', details: 'Unificación de la UX para ingreso a servicios técnicos.' },
        { id: 'd12', title: 'Sistema de Auditoría', date: '2025-12-05', desc: 'Historial detallado (Snapshots, Logs QA).', details: 'Registro inmutable de cada acción realizada sobre un ticket (Quién, Cuándo, Qué).' },
        { id: 'd13', title: 'Corrección Pantalla Blanca', date: '2025-12-05', desc: 'Fix crítico en crash de DestinationSelector.', details: 'Depuración de error de renderizado en el selector de destino móvil.' },
        { id: 'd14', title: 'Formulario Salida Universal', date: '2025-12-05', desc: 'Revisión obligatoria al salir de áreas de Servicio.', details: 'Garantía de calidad que obliga a cerrar procesos antes de mover el ticket.' },
        // d15 Moved to s1 (Urgent) as it was incomplete
        { id: 'd16', title: 'Impresión Código de Barras', date: '2025-12-08', desc: 'Integración Cloud Print para etiquetas térmicas.', details: 'Generación de PDF de etiquetas y encolado en Firestore para impresión remota.' },
        { id: 'd17', title: 'Responsividad Móvil', date: '2025-12-08', desc: 'Kanban apilable y controles táctiles.', details: 'Adaptación completa de la interfaz para uso cómodo en tablets y celulares.' },
        { id: 'd18', title: 'Drag & Drop Nativo', date: '2025-12-09', desc: 'Arrastrar y soltar tickets entre columnas.', details: 'Implementación de API HTML5 DnD para mover tarjetas visualmente.' },
        { id: 'd19', title: 'Filtro de Columnas', date: '2025-12-09', desc: 'Ocultar/Mostrar áreas del tablero.', details: 'Selector persistente para personalizar la vista del tablero según el rol del usuario.' },
        { id: 'd20', title: 'Tarjetas Compactas', date: '2025-12-09', desc: 'Diseño optimizado con Specs y QA Circular.', details: 'Rediseño de tarjeta para mostrar CPU, RAM, Disco y progreso de forma densa.' },
        { id: 'd22', title: 'SLA y KPIs', date: '2025-12-09', desc: 'Reglas de tiempo por área y KPIs.', details: 'Implementación de semáforo de atrasos, Marquee Banner y cálculo de cumplimiento en Dashboard.' },
        { id: 'd8', title: 'Servidor Impresión Local', date: '2025-12-10', desc: 'Script Node.js para conectar USB.', details: 'Implementado servicio local que escucha Firestore e imprime en físico.' },
        { id: 'u7', title: 'Gestión de Usuarios + Roles', date: '2025-12-10', desc: 'Panel Admin para crear técnicos.', details: 'Interfaz para que el Admin gestione cuentas sin código. Implementado Panel + Roles.' },
        { id: 's1', title: '🛡️ Auditoría Reglas Firestore', date: '2025-12-10', desc: 'Hardening de Seguridad.', details: 'Bloqueo Users OnlyAdmin y Tickets inmutables.' },
        { id: 'd23', title: 'Despliegue (Build Final)', date: '2025-12-11', desc: 'Configuración Hosting y Build Ok.', details: 'Generación de bundle y configuración de Firebase Hosting.' },
        { id: 'd24', title: 'Modo Lote (Batch)', date: '2025-12-13', desc: 'Ingreso Masivo de Equipos.', details: 'UX para ingresar múltiples equipos iguales con una sola acción. (Módulo 14).' },
        { id: 'd25', title: 'Sistema Etiquetas V2', date: '2025-12-14', desc: 'Motor PDF Nativo (Sin html2canvas).', details: 'Generación directa de PDF en memoria para prevenir errores de renderizado. (Módulo 16).' },
        { id: 'd26', title: 'Agente Impresión Smart', date: '2025-12-14', desc: 'Auto-Switch de Papel/Orientación.', details: 'Lógica en Node.js para detectar tamaño de etiqueta (50x30 vs 50x70) y configurar driver. (Módulo 15).' },
        { id: 'd27', title: 'Dispatch Form', date: '2025-12-19', desc: 'Ficha de Salida/Venta.', details: 'Formulario final en área Despacho con datos de cliente, checks y transición a venta.' },
        { id: 'd28', title: 'Dashboard Ventas (Admin)', date: '2025-12-19', desc: 'Panel Financiero y KPIs.', details: 'Vista exclusiva Admin con tabla de ventas, cálculo de utilidades, IVA y Costos. (Prev. i11).' },
        { id: 'd29', title: 'Fix Crítico Firestore', date: '2025-12-19', desc: 'Estabilización de Carga.', details: 'Solución a crash "Unexpected State" desactivando persistencia corrupta.' },
        { id: 'd30', title: 'Reglas de Formato (Uppercase)', date: '2025-12-19', desc: 'Estandarización de Datos.', details: 'Forzado automático de MAYÚSCULAS en Nombres, Direcciones, Marcas y Modelos.' }
    ],

    urgent: [
        { id: 'u8', title: '🚀 Puesta en Marcha (Web)', date: '2025-12-10', desc: 'Despliegue Final a URL Pública.', details: 'Subida definitiva a Firebase Hosting y verificación en dispositivos móviles.' },
        { id: 'i10', title: 'Inventario RAM/Disco', date: '2025-12-20', desc: 'Gestión de Stock de Componentes.', details: 'Control de entradas/salidas de insumos clave para reparaciones.' },
    ],
    important: [
        { id: 'i8', title: 'WooCommerce Bridge', date: '2025-12-21', desc: 'Sincronización Stock Web.', details: 'Fase 1: Push de productos desde App a tienda online (Mapeo de datos).' },
        // i11 Moved to Done (d28)
        { id: 'i3', title: 'Homologación Formularios', date: '2025-12-10', desc: 'Clonar preguntas actuales (Google Form).', details: 'Asegurar la paridad de datos al 100% con el sistema antiguo.' },
        { id: 'i9', title: 'Sales Copy AI', date: '2025-12-25', desc: 'Generador de Descripciones con IA.', details: 'Fase 2: Motor de texto persuasivo basado en specs técnicas.' },
        { id: 'i5', title: 'Edición Masiva + Batch', date: '2025-12-11', desc: 'Acciones en lote para tickets.', details: 'Mover, Asignar y Editar múltiples tickets a la vez para eficiencia operativa.' },
        { id: 'i2', title: 'Sistema POS (Caja)', date: '2025-12-12', desc: 'Ventas, Boletas y Presupuestos.', details: 'Módulo financiero completo para cerrar el ciclo de reparación.' },
        { id: 's2', title: '🛡️ Transacciones Atómicas', date: '2025-12-12', desc: 'Integridad Financiera Anti-Glitch.', details: 'Garantía de que no se pierdan pagos ni movimientos de caja si se cae internet.' },
        { id: 's3', title: '🛡️ Firebase App Check', date: '2025-12-13', desc: 'Protección Anti-Clonación/Bots.', details: 'Evita que hackers usen tu API desde otros sitios o scripts maliciosos.' }
    ],
    vision: [
        { id: 'v2', title: 'Portal Clientes (Web)', date: '2025-12-13', desc: 'Seguimiento público por Ticket ID.', details: 'Vista read-only para que clientes consulten estado sin llamar.' },
        { id: 'v1', title: 'Diagnóstico IA Beta', date: '2025-12-14', desc: 'Sugerencias predictivas de fallas.', details: 'Primera implementación de IA para apoyar el diagnóstico técnico.' },
        { id: 'v4', title: 'Módulo Configuración', date: '2025-12-14', desc: 'Gestión de Parámetros Globales.', details: 'Control total de listas, precios y variables del sistema.' },
        { id: 's4', title: '🛡️ Logs Inmutables', date: '2025-12-15', desc: 'Auditoría Forense Anti-Alteración.', details: 'Registro encriptado de "Quién hizo Qué", imposible de borrar incluso para técnicos.' },
        { id: 'v3', title: 'Marketplace Sync', date: '2025-12-15', desc: 'Conexión con E-commerce.', details: 'Sincronización final de stock disponible para la venta online.' }
    ]
};
