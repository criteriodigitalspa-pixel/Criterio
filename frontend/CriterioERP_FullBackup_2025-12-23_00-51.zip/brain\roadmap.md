# Criterio Digital - Roadmap & Historial

## Estatus del Proyecto
Roadmap, Bitácoras y Gestión de Tareas.
**Última Actualización:** 09 Dic 2025

## Historial de Hitos (Timeline)

### Semana 0 (Inicialización)
- **2025-12-05 [Hitu] Inicialización del Proyecto:** Setup de React + Vite + Tailwind y Estructura Backend.
- **2025-12-05 [Hitu] Núcleo Frontend:** Configuración de Tailwind, Rutas y Layout Base.
- **2025-12-05 [Hitu] Integración Firebase:** Inicialización de Firestore y Authentication.
- **2025-12-05 [Hitu] Autenticación:** Login/Registro con Roles (Admin/Técnico).
- **2025-12-05 [Hitu] Dashboard y Layout:** Sidebar responsivo, Modo Oscuro y Branding.
- **2025-12-05 [Hitu] Sistema Smart ID:** IDs autoincrementables (YYMM-XXXX).
- **2025-12-05 [Hitu] Gestión de Inventario:** CRUD básico para ítems de inventario.
- **2025-12-05 [Hitu] Gestión de Tickets:** Esquema avanzado de Ticket y Formularios.
- **2025-12-05 [Hitu] Tablero Kanban:** Visualización de flujo de trabajo en 7 Áreas.
- **2025-12-05 [Hitu] Lógica de Transición:** Movimientos, Validaciones y Formularios por Área.
- **2025-12-05 [Hitu] Servicios Unificados:** Formularios estándar para Servicio Rápido y Dedicado.
- **2025-12-05 [Hitu] Sistema de Auditoría:** Historial detallado (Snapshots, Logs QA).
- **2025-12-05 [Hitu] Corrección Pantalla Blanca:** Fix crítico en crash de DestinationSelector.
- **2025-12-05 [Hitu] Formulario Salida Universal:** Revisión obligatoria al salir de áreas de Servicio.

### Desarrollo Continuo
- **2025-12-08 [Hitu] Impresión Código de Barras:** Integración Cloud Print para etiquetas térmicas.
- **2025-12-08 [Hitu] Responsividad Móvil:** Kanban apilable y controles táctiles.
- **2025-12-09 [Hitu] Drag & Drop Nativo:** Arrastrar y soltar tickets entre columnas.
- **2025-12-09 [Hitu] Filtro de Columnas:** Ocultar/Mostrar áreas del tablero.
- **2025-12-09 [Hitu] Tarjetas Compactas:** Diseño optimizado con Specs y QA Circular.
- **2025-12-09 [Hitu] SLA y KPIs:** Reglas de tiempo por área y KPIs.
- **2025-12-10 [Hitu] Servidor Impresión Local:** Script Node.js para conectar USB.
- **2025-12-10 [Hitu] Gestión de Usuarios + Roles:** Panel Admin para crear técnicos.
- **2025-12-10 [Hitu] 🛡️ Auditoría Reglas Firestore:** Hardening de Seguridad.
- **2025-12-10 [Urgente] 🚀 Puesta en Marcha (Web):** Despliegue Final a URL Pública.
- **2025-12-10 [Próximo] Homologación Formularios:** Clonar preguntas actuales (Google Form).
- **2025-12-11 [Hitu] Despliegue (Build Final):** Configuración Hosting y Build Ok.
- **2025-12-11 [Próximo] Edición Masiva + Batch:** Acciones en lote para tickets.
- **2025-12-12 [Próximo] Sistema POS (Caja):** Ventas, Boletas y Presupuestos.
- **2025-12-12 [Próximo] 🛡️ Transacciones Atómicas:** Integridad Financiera Anti-Glitch.
- **2025-12-13 [Hitu] Modo Lote (Batch):** Ingreso Masivo de Equipos.
- **2025-12-13 [Próximo] 🛡️ Firebase App Check:** Protección Anti-Clonación/Bots.

### Visión Futura
- **2025-12-13 [Visión] Portal Clientes (Web):** Seguimiento público por Ticket ID.
- **2025-12-14 [Hitu] Sistema Etiquetas V2:** Motor PDF Nativo (Sin html2canvas).
- **2025-12-14 [Hitu] Agente Impresión Smart:** Auto-Switch de Papel/Orientación.
- **2025-12-14 [Visión] Diagnóstico IA Beta:** Sugerencias predictivas de fallas.
- **2025-12-14 [Visión] Módulo Configuración:** Gestión de Parámetros Globales.
- **2025-12-15 [Visión] 🛡️ Logs Inmutables:** Auditoría Forense Anti-Alteración.
- **2025-12-15 [Visión] Marketplace Sync:** Conexión con E-commerce.

### Activo Reciente
- **2025-12-19 [Hitu] Dispatch Form:** Ficha de Salida/Venta.
- **2025-12-19 [Hitu] Dashboard Ventas (Admin):** Panel Financiero y KPIs.
- **2025-12-19 [Hitu] Fix Crítico Firestore:** Estabilización de Carga.
- **2025-12-19 [Hitu] Reglas de Formato (Uppercase):** Estandarización de Datos.
- **2025-12-20 [Urgente] Inventario RAM/Disco:** Gestión de Stock de Componentes.
- **2025-12-21 [Próximo] WooCommerce Bridge:** Sincronización Stock Web.
- **2025-12-25 [Próximo] Sales Copy AI:** Generador de Descripciones con IA.
