# Protocolo de Supervivencia: Criterio Digital ERP (Black Swan Proof)

> **⚠️ ESTE DOCUMENTO ES CRÍTICO.** Guárdalo en múltiples ubicaciones físicas y en la nube (USB Offline, Google Drive, Email Cifrado).

## 1. Visión General del Sistema
Si lees esto, asumo que has perdido acceso al entorno de desarrollo original. Aquí tienes lo necesario para reconstruir **Criterio Digital ERP**.

### Stack Tecnológico
- **Frontend:** React (Vite) + Tailwind CSS + Javascript Moderno.
- **Backend/Datos:** Firebase (Firestore) + Firebase Auth (Identidad).
- **Control de Versiones:** Git (Local no sincronizado).
- **Estado Global:** Context API (`AuthContext`, `ProcessingContext`, `GlobalSearch`).

---

## 2. Archivo De Respaldo Maestro
El script adjunto `generar_backup.ps1` creará un archivo ZIP llamado `CriterioERP_FullBackup_YYYY-MM-DD.zip`. Este archivo contiene:
1.  **Código Fuente Completo:** `src/`, `public/`.
2.  **Configuraciones de Build:** `vite.config.js`, `package.json`, etc.
3.  **Cerebro del Proyecto:** `brain/` (Toda la documentación, roadmaps, guías).
4.  **Variables de Entorno:** `.env` (TUS LLAVES SECRETAS - ¡CUIDADO!).

---

## 3. Protocolo de Restauración (Desde Cero)

### Paso A: Instalar Entorno
En una PC nueva y limpia:
1.  **Instalar Node.js:** Descarga la versión LTS (v18 o superior) desde [nodejs.org](https://nodejs.org).
2.  **Instalar Git:** (Opcional pero recomendado) desde [git-scm.com](https://git-scm.com).
3.  **Instalar VS Code:** Tu editor de código.

### Paso B: Descomprimir y Preparar
1.  Descomprime el `CriterioERP_FullBackup.zip` en una carpeta (ej: `C:\Proyectos\CriterioERP`).
2.  Abre esa carpeta en VS Code.
3.  Abre una terminal (`Ctrl + ñ`) y ejecuta:
    ```powershell
    npm install
    ```
    *Esto descargará todas las librerías necesarias (React, Tailwind, Lucide, etc).*

### Paso C: Verificar Credenciales (.env)
Asegúrate de que el archivo `.env` existe en la raíz y tiene tus llaves de Firebase. Si lo perdiste, necesitarás ir a la Consola de Firebase -> Configuración del Proyecto -> General y copiar la configuración del SDK.

### Paso D: Iniciar Sistema
Ejecuta:
```powershell
npm run dev
```
El sistema debería revivir en `http://localhost:5173`.

---

## 4. Respaldo de Datos (La Base de Datos)
El código no sirve de nada sin tus datos (Clientes, Tickets). Dado que usamos Firebase en la nube, tus datos están seguros en los servidores de Google, **pero si pierdes acceso a tu cuenta de Google, los pierdes.**

### Exportación Manual (Recomendado Mensual)
1.  Ve a [Firebase Console](https://console.firebase.google.com).
2.  Selecciona tu proyecto.
3.  Ve a **Firestore Database** -> Pestaña **Datos**.
4.  No hay botón de "Descargar Todo" en la UI web fácilmente. **Usa este método:**
    *   Ve a **Google Cloud Console** (vinculada a tu proyecto).
    *   Usa la herramienta **Export/Import** de Firestore para generar un backup en un Bucket de Cloud Storage.
    *   Descarga esos archivos del Bucket a tu PC.

### Respaldo de Emergencia (JSON)
También puedes usar herramientas de terceros o scripts (ver `scripts/backup_firestore.js` si lo creamos) para bajar un JSON de tus colecciones principales (`tickets`, `users`, `products`).

---

## 5. Contactos y Accesos Críticos
Anota aquí (o en un gestor de contraseñas físico) los correos de recuperación.

*   **Cuenta Google Admin:** [TU_CORREO_ADMIN]
*   **Hosting Frontend:** (Si usas Vercel/Netlify)
*   **Dominio:** (Proveedor de Dominio)

---

**Fin del Protocolo.**
*Con este archivo y el ZIP generado, eres indestructible.*
