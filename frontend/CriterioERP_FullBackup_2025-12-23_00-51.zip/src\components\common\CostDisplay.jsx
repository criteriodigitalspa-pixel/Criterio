
import React from 'react';
import { useFinancialsContext } from '../../context/FinancialContext';
import { DollarSign, ArrowUp, ArrowDown } from 'lucide-react';
import clsx from 'clsx';

export default function CostDisplay({ ticket, compact = false }) {
    const { calculateFinancials, loading } = useFinancialsContext();

    if (loading) return <span className="animate-pulse bg-gray-700 h-4 w-12 rounded"></span>;
    if (!ticket) return null;

    const { totalCost, ramDelta, isModified, baseCost, serviceCost } = calculateFinancials(ticket);

    const format = (n) => new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(n);

    // Color Logic:
    // + Delta (Cost Increase) -> Red (Expense) or specific logic? 
    // Usually upgrading RAM adds value, but costs money. 
    // Let's use standard: + = Red (Cost), - = Green (Save).
    const deltaColor = ramDelta > 0 ? "text-red-400" : "text-green-400";
    const Arrow = ramDelta > 0 ? ArrowUp : ArrowDown;

    const [showBreakdown, setShowBreakdown] = React.useState(false);

    if (compact === 'icon') {
        return (
            <div className="relative inline-block" onClick={(e) => e.stopPropagation()}>
                <div
                    onClick={() => setShowBreakdown(!showBreakdown)}
                    className={clsx(
                        "flex items-center justify-center w-5 h-5 rounded-full border cursor-pointer transition-colors shadow-sm",
                        showBreakdown
                            ? "bg-emerald-900 text-emerald-400 border-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]"
                            : "bg-gray-800 text-emerald-600 border-gray-600 hover:bg-gray-700"
                    )}
                >
                    <DollarSign className="w-3 h-3 stroke-[2.5]" />
                </div>

                {/* Tooltip / Breakdown */}
                {showBreakdown && (
                    <div className="absolute top-0 right-7 mt-0 w-64 bg-gray-900/95 backdrop-blur-md rounded-xl border border-gray-700 shadow-2xl p-4 z-[9999] animate-in fade-in zoom-in-95 origin-top-right text-left">
                        {/* Close Handler Overlay (Optional) */}
                        <div className="absolute top-2 -right-1.5 w-3 h-3 bg-gray-900/95 rotate-45 border-r border-t border-gray-700"></div>

                        <h4 className="text-[10px] font-bold text-gray-400 uppercase border-b border-gray-700/50 pb-2 mb-2 tracking-wider">Historial de Costos</h4>

                        <div className="space-y-2">
                            {/* 1. Base Cost */}
                            <div className="flex justify-between items-center text-xs">
                                <span className="text-gray-500">Valor Base (Compra)</span>
                                <span className="text-gray-300 font-mono">{format(baseCost)}</span>
                            </div>

                            {/* 2. Hardware Upgrades */}
                            {ramDelta !== 0 && (
                                <div className="flex justify-between items-center text-xs">
                                    <span className="text-blue-400">Upgrade Hardware</span>
                                    <span className={clsx("font-mono font-bold", ramDelta > 0 ? "text-red-400" : "text-green-400")}>
                                        {ramDelta > 0 ? '+' : ''}{format(ramDelta)}
                                    </span>
                                </div>
                            )}

                            {/* 3. Service Costs */}
                            {serviceCost > 0 && (
                                <div className="flex justify-between items-center text-xs">
                                    < span className="text-orange-400">Servicios / Mano de Obra</span>
                                    <span className="text-red-400 font-mono font-bold">+{format(serviceCost)}</span>
                                </div>
                            )}

                            {/* Total */}
                            <div className="border-t border-gray-700/50 pt-2 mt-2 flex justify-between items-center">
                                <span className="text-xs font-bold text-green-400 uppercase">Costo Total</span>
                                <span className="font-mono text-white font-bold text-sm tracking-tight">{format(totalCost)}</span>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        );
    }

    if (compact) {
        // Ticket Card Version (Legacy Compact - can be removed if strictly replacing)
        return (
            <div className="flex items-center gap-1 text-[10px] font-mono font-bold bg-gray-900/50 px-1.5 py-0.5 rounded border border-gray-700/50">
                <span className="text-gray-300">{format(totalCost)}</span>
                {isModified && (
                    <span className={clsx("flex items-center", deltaColor)}>
                        {ramDelta > 0 ? '+' : ''}{format(ramDelta)}
                    </span>
                )}
            </div>
        );
    }

    // Full Version (Modal)
    return (
        <div className="bg-gray-900/50 p-3 rounded-xl border border-gray-700 flex items-center justify-between">
            <div>
                <span className="text-xs text-gray-400 font-bold uppercase block mb-0.5">Costo Total Equipamiento</span>
                <div className="text-2xl font-mono font-bold text-white tracking-tight flex items-baseline gap-2">
                    {format(totalCost)}
                    {(ramDelta !== 0 || serviceCost > 0) && (
                        <div className="flex gap-2">
                            {ramDelta !== 0 && (
                                <div className={clsx("text-xs flex items-center gap-1 bg-gray-800 px-2 py-1 rounded-full border border-gray-700", deltaColor)}>
                                    <Arrow className="w-3 h-3" />
                                    <span>RAM: {ramDelta > 0 ? '+' : ''}{format(ramDelta)}</span>
                                </div>
                            )}
                            {serviceCost > 0 && (
                                <div className="text-xs flex items-center gap-1 bg-gray-800 px-2 py-1 rounded-full border border-gray-700 text-red-400">
                                    <ArrowUp className="w-3 h-3" />
                                    <span>SVC: +{format(serviceCost)}</span>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
            {(isModified || serviceCost > 0) && (
                <div className="text-right">
                    <span className="text-[10px] text-gray-500 block">Costo Base: {format(ticket.precioCompra || 0)}</span>
                </div>
            )}
        </div>
    );
}
