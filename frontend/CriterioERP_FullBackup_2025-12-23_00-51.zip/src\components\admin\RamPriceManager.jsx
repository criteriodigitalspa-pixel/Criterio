import { useState, useEffect } from 'react';
import { Trash2, Save, Plus, AlertCircle, Edit2, X, DollarSign } from 'lucide-react';
import { db, auth } from '../../services/firebase'; // Direct DB or Service? Let's use direct for speed in admin component or create service method.
import { collection, addDoc, getDocs, deleteDoc, doc, updateDoc, query, orderBy, serverTimestamp } from 'firebase/firestore';
import toast from 'react-hot-toast';

const COLLECTION = 'hardware_prices';

export default function RamPriceManager() {
    const [prices, setPrices] = useState([]);
    const [loading, setLoading] = useState(true);
    const [editingId, setEditingId] = useState(null);

    // Form State
    const [formData, setFormData] = useState({
        type: 'DDR4',
        capacity: '8GB',
        price: '',
        frequency: ''
    });

    const RAM_TYPES = ['DDR3', 'DDR3L', 'DDR4', 'DDR5'];
    const RAM_CAPACITIES = ['2GB', '4GB', '8GB', '12GB', '16GB', '32GB', '64GB'];

    // Load Prices
    const loadPrices = async () => {
        setLoading(true);
        try {
            // REMOVED orderBy to avoid Index Requirement error
            const q = query(collection(db, COLLECTION));
            const snapshot = await getDocs(q);
            const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));

            // Client-side Sort
            data.sort((a, b) => {
                if (a.type !== b.type) return a.type.localeCompare(b.type);
                // Simple capacity sort (approximate for strings "8GB" vs "16GB", but functional enough or can be improved)
                return a.capacity.localeCompare(b.capacity, undefined, { numeric: true });
            });

            setPrices(data);
        } catch (error) {
            console.error("Error loading prices:", error);
            toast.error("Error cargando precios: " + error.message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadPrices();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!formData.price) return;

        if (!auth.currentUser) {
            toast.error("Error: No estás autenticado. Recarga la página.");
            console.error("Auth Check Failed: currentUser is null");
            return;
        }
        console.log("Saving with User:", auth.currentUser.uid);

        try {
            const payload = {
                category: 'RAM',
                type: formData.type,
                capacity: formData.capacity,
                price: parseInt(formData.price),
                updatedAt: serverTimestamp()
            };

            if (editingId) {
                await updateDoc(doc(db, COLLECTION, editingId), payload);
                toast.success("Precio actualizado");
                setEditingId(null);
            } else {
                // Check duplicate?
                const exists = prices.find(p => p.type === formData.type && p.capacity === formData.capacity);
                if (exists) {
                    toast.error("Ya existe un precio para esta configuración. Edítalo en su lugar.");
                    return;
                }
                await addDoc(collection(db, COLLECTION), payload);
                toast.success("Precio agregado");
            }

            setFormData({ type: 'DDR4', capacity: '8GB', price: '', frequency: '' });
            loadPrices();
        } catch (error) {
            console.error("Save Error:", error);
            const projectId = auth.app.options.projectId;
            toast.error(`Error (${projectId}): ${error.message} \n Reglas: ${error.code}`);
        }
    };

    const handleEdit = (item) => {
        setEditingId(item.id);
        setFormData({
            type: item.type,
            capacity: item.capacity,
            price: item.price,
            frequency: item.frequency || ''
        });
    };

    const handleDelete = async (id) => {
        if (!window.confirm("¿Eliminar este precio?")) return;
        try {
            await deleteDoc(doc(db, COLLECTION, id));
            toast.success("Eliminado");
            loadPrices();
        } catch (error) {
            toast.error("Error eliminando");
        }
    };

    const formatMoney = (amount) => {
        return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(amount);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-xl font-bold text-white">Lista de Precios RAM</h2>
                    <p className="text-gray-400 text-sm">Gestiona los costos base para las memorias RAM.</p>
                </div>
            </div>

            {/* FORM */}
            <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700">
                <form onSubmit={handleSubmit} className="flex flex-wrap gap-4 items-end">

                    <div>
                        <label className="block text-xs font-bold text-gray-400 mb-1">TIPO</label>
                        <select
                            value={formData.type}
                            onChange={e => setFormData({ ...formData, type: e.target.value })}
                            className="bg-gray-900 border border-gray-600 rounded-lg p-2 text-white w-32 focus:border-blue-500 outline-none"
                        >
                            {RAM_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                        </select>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-400 mb-1">CAPACIDAD</label>
                        <select
                            value={formData.capacity}
                            onChange={e => setFormData({ ...formData, capacity: e.target.value })}
                            className="bg-gray-900 border border-gray-600 rounded-lg p-2 text-white w-32 focus:border-blue-500 outline-none"
                        >
                            {RAM_CAPACITIES.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>

                    <div className="flex-1 min-w-[150px]">
                        <label className="block text-xs font-bold text-gray-400 mb-1">PRECIO (CLP)</label>
                        <div className="relative">
                            <DollarSign className="w-4 h-4 absolute left-3 top-2.5 text-gray-500" />
                            <input
                                type="number"
                                value={formData.price}
                                onChange={e => setFormData({ ...formData, price: e.target.value })}
                                placeholder="0"
                                className="bg-gray-900 border border-gray-600 rounded-lg pl-9 p-2 text-white w-full focus:border-blue-500 outline-none font-mono"
                            />
                        </div>
                    </div>

                    <button
                        type="submit"
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold transition-all ${editingId
                            ? 'bg-yellow-600 hover:bg-yellow-500 text-white'
                            : 'bg-blue-600 hover:bg-blue-500 text-white'
                            }`}
                    >
                        {editingId ? <><Save className="w-4 h-4" /> Actualizar</> : <><Plus className="w-4 h-4" /> Agregar</>}
                    </button>

                    {editingId && (
                        <button
                            type="button"
                            onClick={() => { setEditingId(null); setFormData({ type: 'DDR4', capacity: '8GB', price: '' }); }}
                            className="p-2 text-gray-400 hover:text-white"
                        >
                            <X className="w-5 h-5" />
                        </button>
                    )}
                </form>
            </div>

            {/* LIST */}
            <div className="space-y-2">
                {prices.filter(p => p.category === 'RAM').map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-4 bg-gray-800 rounded-lg border border-gray-700 hover:bg-gray-750 transition-colors group">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-lg bg-blue-900/20 flex items-center justify-center border border-blue-500/20 text-blue-400 font-bold text-xs flex-col">
                                <span>{item.type}</span>
                            </div>
                            <div>
                                <h4 className="text-white font-bold text-lg">{item.capacity}</h4>
                                <div className="flex flex-col">
                                    <span className="text-xs text-gray-500">RAM - {item.type}</span>
                                    {item.updatedAt && (
                                        <span className="text-[10px] text-gray-600">
                                            {item.updatedAt.toDate ? item.updatedAt.toDate().toLocaleDateString() : 'Reciente'}
                                        </span>
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center gap-6">
                            <div className="text-right">
                                <span className="block text-2xl font-bold text-green-400 font-mono tracking-tight">
                                    {formatMoney(item.price)}
                                </span>
                                <span className="text-[10px] text-gray-500 uppercase tracking-wider">Costo Base</span>
                            </div>

                            <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                    onClick={() => handleEdit(item)}
                                    className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-yellow-400 transition-colors"
                                    title="Editar"
                                >
                                    <Edit2 className="w-4 h-4" />
                                </button>
                                <button
                                    onClick={() => handleDelete(item.id)}
                                    className="p-2 bg-gray-700 hover:bg-red-900/50 rounded-lg text-red-400 transition-colors"
                                    title="Eliminar"
                                >
                                    <Trash2 className="w-4 h-4" />
                                </button>
                            </div>
                        </div>
                    </div>
                ))}

                {prices.length === 0 && !loading && (
                    <div className="text-center p-8 text-gray-500 border border-dashed border-gray-700 rounded-xl">
                        No hay precios de RAM configurados. Agrega uno arriba.
                    </div>
                )}
            </div>
        </div>
    );
}
